function J = RELSFunc(x, PHI, M, Y, u_coords, v_coords)

    %memory length
    n = M; %for 1st order kernel

    %V and U coordinate system setup for 2D kernel

    c1 = x(1);          
    lambda1 = x(2);
    c2 = x(3);
    lambda2 = x(4);
    lambda3 = x(5);
    noise_std = x(6); 

    P1 = zeros(n);
    for j = 1:n
        for k = 1:n
            P1(j,k) = c1*lambda1^(max([j k]));
        end
    end

    n2 = (n^2+n)/2;
    P2v = zeros(n2);
    P2u = zeros(n2);

    for i = 1:n2
        for j = i:n2
            P2v(i,j) = lambda2^(max(v_coords(i),v_coords(j)));
            P2v(j,i) = P2v(i,j);
            P2u(i,j) = lambda3^(max(u_coords(i),u_coords(j)));
            P2u(j,i) = P2u(i,j);
        end
    end

    P2 = c2*P2v.*P2u; 

    P = blkdiag(P1, P2);
    P = P+1e-10*eye(size(P)); %Make sure P is positive definite

    Y = Y(:); %Make Y a column vector
    SigYa = PHI'*P*PHI; %Compute first component of covariance
    SigY = SigYa + noise_std^2*eye(length(SigYa)); %Compute full covariancew
    [Q,R] = qr(SigY); %QR Factorization of covariance 
    J = Y'/R*Q'*Y + sum(log(abs(diag(R)))); %Numerically robust implementation of: Y'*inv(SigY)*Y + log(det(SigY))

end
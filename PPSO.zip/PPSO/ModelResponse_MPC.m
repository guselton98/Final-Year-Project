clc; clear;

Ts = 15;
load('tank_inout18_001_008.mat');
% plot(h1); 
% figure();
% surf(h2);

n = length(h1)
[n_2, ~] = size(h2)

%% Input step response
input = [3.5*zeros(1,70), 3.5*ones(1,930)];

% Initialise output
output = zeros(1, 1000);


% Output response- Volterra Series Expansion :D
for t = 71:1000
    
    % Offset
    order_0 = 0;
    
    % First order response
    order_1 = 0;
    for i = 1:n
        order_1 = order_1+h1(i)*input(t-i);
    end
    
    
     % Second order response
    order_2 = 0;
    for i = 1:n_2
        for j = 1:n_2
            order_2 = order_2+h2(i,j)*input(t-i)*input(t-j);
        end
    end
    
    output(t) = order_0+order_1 + order_2;
    
end

plot(output);


%% Does input and output data work when substituted in?
input = [3.5*zeros(1,70), u];
[~, N] = size(input);
% Initialise output
output = zeros(1, N+70);

figure();
subplot(2,1,1)
plot(input);
title('Original input')
subplot(2,1,2)
plot([zeros(1,70), y]);
hold on
title('Output')

% Output response- Volterra Series Expansion :D
for t = 71:800
    
    % Offset
    order_0 = 0;
    
    % First order response
    order_1 = 0;
    for i = 1:n
        order_1 = order_1+h1(i)*input(t-i);
    end
    
    
     % Second order response
    order_2 = 0;
    for i = 1:n_2
        for j = 1:n_2
            order_2 = order_2+h2(i,j)*input(t-i)*input(t-j);
        end
    end
    
    output(t) = order_0+order_1 + order_2;
    
end

plot(output);


%% Does the data match the complete data set?
clc; clear;

Ts = 15;
load('tank_inout18_001_008.mat');

n = length(h1)
[n_2, ~] = size(h2)

load('inout_018.mat');
[~, ydata,udata] = inout_018.Y.Data;

%Initialise domain with zeros
input = [zeros(1, 70), udata];
[~, N] = size(input);
figure();
subplot(2,1,1)
plot(input);
title('Input N(3.5, 40)')
ylabel('Pump (V)')
subplot(2,1,2)
plot([zeros(1,70), ydata]);
hold on
title('Ouput');

% Output response- Volterra Series Expansion :D
for t = 71:N
    
    % Offset
    order_0 = 0;
    
    % First order response
    order_1 = 0;
    for i = 1:n
        order_1 = order_1+h1(i)*input(t-i);
    end
    
    
     % Second order response
    order_2 = 0;
    for i = 1:n_2
        for j = 1:n_2
            order_2 = order_2+h2(i,j)*input(t-i)*input(t-j);
        end
    end
    
    output(t) = order_0+order_1 + order_2;
    
end

plot(output);
ylabel('Water Level (V)')
xlabel('Samples [k], Ts = 15 sec')
legend('True Output', 'Estimated Output');

%% Does the data match another differrent data set?
clc; clear;

Ts = 15;
load('tank_inout18_001_008.mat');

n = length(h1);
[n_2, ~] = size(h2);

figure();
subplot(2,1,1)
plot(h1);
title('1st Order Kernel')
subplot(2,1,2)
surf(h2);
title('2nd Order Kernel');


load('inout_016.mat');
[ydata,udata] = inout_016.Y.Data;
ydata = [zeros(1,70), ydata];
%Initialise domain with zeros
input = [zeros(1, 70), udata];
[~, N] = size(input);
figure();
subplot(2,1,1)
plot(input);
title('Input N(3.5, 40)')
ylabel('Pump (V)')
subplot(2,1,2)
plot(ydata);
hold on
title('Ouput');

% Output response- Volterra Series Expansion :D
for t = 71:N
    
    % Offset
    order_0 = 0;
    
    % First order response
    order_1 = 0;
    for i = 1:n
        order_1 = order_1+h1(i)*input(t-i);
    end
    
    
     % Second order response
    order_2 = 0;
    for i = 1:n_2
        for j = 1:n_2
            order_2 = order_2+h2(i,j)*input(t-i)*input(t-j);
        end
    end
    
    output(t) = order_0+order_1 + order_2;
    
end

plot(output);
ylabel('Water Level (V)')
xlabel('Samples [k], Ts = 15 sec')
legend('True Output', 'Estimated Output');

% Performance
dif = output - ydata;
rmse = sqrt(sum(dif.^2)/N)

%% MPC
clc; clear;
load('tank_inout18_001_008.mat');

disturbance = 0;

alpha0_v = 0;
alpha1 = [0.134239812794157;-0.0689563028548157;-0.0831297180397173;-0.00612976075748904;-0.00784079312987619;-0.000909281432386887;-0.000262877784088585;-0.000106535206393407;-1.18942970048429e-05;-1.25188379482496e-06;-9.90041092521994e-07;-2.95896025161818e-07];
alpha1_v = alpha1';
alpha2 = [0.00627798528682828,0.00365851299301021,-0.00186937561524310,0.00162900818403939,2.62939792691331e-05,0.000146642973723787,-0.000108915022569773,4.60650337933819e-05,1.03419813628591e-05,1.44156989514494e-07,-8.80895429457505e-07,-9.93151085333483e-08;0.00365851299301021,0.00230003636731273,-0.00109753540153708,-0.000856408982008715,-7.13034036395868e-06,-0.000121071215922511,-3.00912327479632e-06,1.63666754279219e-05,3.87855323105942e-06,-3.64047932465153e-07,-2.26939891182798e-07,8.37387843325656e-09;-0.00186937561524310,-0.00109753540153708,0.00110386000751393,-0.000146815298286004,-0.000135044577873473,2.64202324844852e-05,1.46452489862620e-05,6.98604166003814e-06,1.39960349242178e-06,3.26414980161598e-07,4.71032022672753e-08,2.77712235049018e-08;0.00162900818403939,-0.000856408982008715,-0.000146815298286004,9.31816979541708e-05,-1.30186648699139e-05,2.12389166889539e-05,8.93131929305709e-06,3.72489635786961e-06,1.20484105668269e-06,3.29491728331012e-07,7.67610176839359e-08,2.11721397591793e-08;2.62939792691331e-05,-7.13034036395868e-06,-0.000135044577873473,-1.30186648699139e-05,1.10619805676222e-05,-1.83357274037829e-07,2.62000948303811e-06,2.30834305073455e-06,7.73793336573094e-07,1.96704113773700e-07,4.36647814943858e-08,1.29040730487302e-08;0.000146642973723787,-0.000121071215922511,2.64202324844852e-05,2.12389166889539e-05,-1.83357274037829e-07,2.35449782298244e-06,2.25314657790107e-06,1.32673714298920e-06,3.92606659599042e-07,9.12208422649905e-08,2.24809346920071e-08,6.29946862039466e-09;-0.000108915022569773,-3.00912327479632e-06,1.46452489862620e-05,8.93131929305709e-06,2.62000948303811e-06,2.25314657790107e-06,1.65685240112407e-06,6.14874038035731e-07,1.60225977061987e-07,4.02677806295622e-08,1.01141716239744e-08,2.68594947118246e-09;4.60650337933819e-05,1.63666754279219e-05,6.98604166003814e-06,3.72489635786961e-06,2.30834305073455e-06,1.32673714298920e-06,6.14874038035731e-07,2.34152617513736e-07,6.30047384238699e-08,1.63571004398114e-08,4.07090534926998e-09,1.01634215262733e-09;1.03419813628591e-05,3.87855323105942e-06,1.39960349242178e-06,1.20484105668269e-06,7.73793336573094e-07,3.92606659599042e-07,1.60225977061987e-07,6.30047384238699e-08,2.11744236330373e-08,5.60650672115515e-09,1.36014572596972e-09,3.25549209958359e-10;1.44156989514494e-07,-3.64047932465153e-07,3.26414980161598e-07,3.29491728331012e-07,1.96704113773700e-07,9.12208422649905e-08,4.02677806295622e-08,1.63571004398114e-08,5.60650672115515e-09,1.68289751549852e-09,3.91113414934388e-10,9.99638441578880e-11;-8.80895429457505e-07,-2.26939891182798e-07,4.71032022672753e-08,7.67610176839359e-08,4.36647814943858e-08,2.24809346920071e-08,1.01141716239744e-08,4.07090534926998e-09,1.36014572596972e-09,3.91113414934388e-10,1.09200864867460e-10,2.92427211165466e-11;-9.93151085333483e-08,8.37387843325656e-09,2.77712235049018e-08,2.11721397591793e-08,1.29040730487302e-08,6.29946862039466e-09,2.68594947118246e-09,1.01634215262733e-09,3.25549209958359e-10,9.99638441578880e-11,2.92427211165466e-11,9.24799705570547e-12];
alpha2_v = reshape(alpha2', 1, ML*ML);

%Laguerre Memory length
L_ML = ML;      %B_m

%A and B matrices
A1 = zeros(L_ML);
A2 = zeros(L_ML);  
B1 = zeros(L_ML,1);
B2 = zeros(L_ML,1);

%Laguerre Poles
a = [pole1D, pole2D];               %a_m
r = [1-a(1).^2, 1-a(2).^2];         %r_m = 1-a^2

%dimensional order = 2
order = 2;

%FORM A and B State Matrices (10.10) and (10.11)
%Each row
for i = 1:L_ML

    B1(i) = sqrt(r(1))*(-a(1))^(i-1);
    B2(i) = sqrt(r(2))*(-a(2))^(i-1);
    %Each column
    for j = 1:i

        %Each diagonal
        if i == j

             A1(i,j) = a(1);
             A2(i,j) = a(2);

        %Each diagonal - 1     
        elseif j == i-1

            A1(i,j) = r(1);
            A2(i,j) = r(2);

        %Everything else   
        else

            A1(i,j) = (-a(1))^(i-j-1)*r(1);
            A2(i,j) = (-a(2))^(i-j-1)*r(2);

        end

    end

end

% Initial filtered inputs
u = zeros(1,70);
% u = ones(0.5,0.5,0.5);
z = tf('z');
%Store filtered inputs
fu = zeros(ML,max(size(u)));
gu = fu;

%plength: number of filters
for k = 1:ML
    %Find tranfer function of 1st order filter, f
    f = sqrt(1-pole1D^2)/(z-pole1D)*((1-pole1D*z)/(z-pole1D))^(k-1);
    %Extract coefficients
    [num1,den1] = tfdata(f,'v');
    %Filters inputs, u, through filter f, f+u = fu
    fu(k, :) = filter(num1, den1, u);

    %Find tranfer function of 2nd order filter, g
    g = sqrt(1-pole2D^2)/(z-pole2D)*((1-pole2D*z)/(z-pole2D))^(k-1);
    %Extract coefficients
    [num2,den2] = tfdata(g,'v');
    %Filters inputs, u, through filter g, g+u = gu
    gu(k, :) = filter(num2, den2, u);
end

x1 = fu;
x2 = gu;

% Control
G_u = 1;      % G_u (input penatly, Gamma_u)
G_y = 1;      % G_y (output - ref penatly)
p = 20;          % p (prediction horizon)
ref = [0*ones(1, 70),6*ones(1, 430)];      % ref (reference tracking: consider constant for now)
mu = 1;         % mu (move horizon)                        
control = 1;    %1/0
j = p/mu;       %Calculate required steps
M = 2;          % dimensions of impulse (exclude 0 order)

gamma = zeros(M+1, j);      % Xj coefficients over all jth time instances
beta = zeros(2*M, j);       % Xj.d/du.Xj coefficients

u_best = 0;                 % u root to give lowest cost
Xj = zeros(1, p);
dXj = zeros(1, p);

% Time increment ([t] -> t != 0, t > 0)
% initial time: t = 1, start control at t = 3
t = 70;
while(control)
    
    Abar1 = eye(size(A1));
    Abar2 = eye(size(A2)); 
    Aj1 = A1;
    Aj2 = A2;
    
    for i=1:j

%STEP 2: COMPUTE Xj polynomial coefficients (10.19 & 10.20)

        % Offset 0th order: CORRECT
        gamma(1, i) = alpha0_v + ...
                        alpha1_v*(Aj1*x1(:,t)) + ...
                        alpha2_v*kron((Aj2*x2(:,t)),(Aj2*x2(:,t))) -...
                        ref(t) + disturbance;

        % 1st order: CORRECT
        gamma(2, i) = alpha1_v*(Abar1*B1) + ...
                        alpha2_v*(kron(Aj2*x2(:, t), Abar2*B2) + kron(Abar2*B2, Aj2*x2(:, t)));

        % 2nd order: CORRECT
        gamma(3, i) = alpha2_v*(kron(Abar2*B2, Abar2*B2)); 
        
        %Xj = gamma(1) + gamma(2).u(t) + gamma(3).u^2(t)
        
%STEP 3: COMPUTE Xj.d/du.Xj coefficients (10.22): CHECKED/CORRECT

        % Extract jth coefficients from gamma, place in decreasing order
        % u_conv = [gamma(3).u^2(t), gamma(2).u(t), gamma(1)]
        u_conv = fliplr(gamma(:, i)');
        
        %v_conv = [2.gamma(3).u(t), 1.gamma(2)]
        v_conv = zeros(1, M);
        
        %Extract values from u and derive: CORRECT
        for k = 1:M
            v_conv(k) = (M-k+1)*u_conv(k);
        end
        
        %Convolve u and v to form beta coefficients
        % beta : [beta(2M-1)..., beta2, beta1 ,beta0]: CHECKED/CORRECT
        beta(:, i) = conv(u_conv, v_conv)';
        
                
%STEP 1: COMPUTE Abar1 and Abar2 ????? - NEED TO DO
        % Assume Abar1 = A1 and Abar2 = A2
        % Change with j somehow below (10.14)
        
%         Abar1 = Abar1 + A1 + eye(size(A1)); 
%         
%         Abar2 = Abar2 + A2 + eye(size(A2));

          Abar1 = Abar1 + Aj1; 
          Abar2 = Abar2 + Aj2;
          Aj1 = Aj1*A1;
          Aj2 = Aj2*A2;
    end
    
    % Arrange coefficients in increasing order (makes it easier finding row...) 
    % beta : [beta0, beta1, beta2,...,beta(2M-1)]
    beta = flip(beta);
    
%STEP 4: Compute coefficients of the minimizer polynomial, row (10.23)
    % let row = SUM(beta_{2M-1, j}) for j=1 to p
    % row : [r0, r1, r2 ... r(2M-1)]
    row = zeros(1, 2*M);
    
    for i = 1:2*M
        
        %r0
        if i == 1
        
            row(i) = sum(beta(i, :)) - G_u^2*u(t-1);
            
        %r1    
        elseif i == 2
        
            row(i) = sum(beta(i, :)) + G_u^2;
            
        %r2,...r(2M-1)
        else
            
            row(i) = sum(beta(i, :));
            
        end
        
    end
    
%STEP 5: Find all roots of minimizer (10.23)
    u_values = roots(fliplr(row));
    
%STEP 6: Evaluate objective function for all REAL roots (10.12)
    real_u_values = 0;
    
    % Create buffer size to store costs
    for i = 1:max(size(u_values))
        % Evaluate for REAL roots only
        if imag(u_values(i)) == 0
            %Add length to real buffer
            real_u_values = real_u_values+1;
        end
    end
    
    %Create cost and u buffers
    real_cost_values_buffer = zeros(1, real_u_values);
    real_u_values_buffer = zeros(1, real_u_values);
    real_u_values = 0;
    
    
    for i = 1:max(size(u_values))
        % Evaluate for REAL roots only
        if imag(u_values(i)) == 0
            
            real_u_values = real_u_values+1;
            real_u_values_buffer(real_u_values) = u_values(i);
            
%           (10.15 to 10.16): using u*(t)
            for j = 1:p
                Xj(j) = gamma(3, j)*real_u_values_buffer(real_u_values)^2+...
                    gamma(2, j)*real_u_values_buffer(real_u_values)+...
                    gamma(1, j);
            end
            
            %ISSUE: Evaluate cost sum((yoff(t)-ref)^2) == Xj !!!!!!!!!!!!
            %ISSUE: not evaluating u*(t)
            %Assume: u(t) = [1, 1], u*(t) = root
            %in 10.15, u(t) = u*(t), u(t-1) = u(t)
%            real_cost_values_buffer = sum((yoff(t)-ref).^2)+ G_u*(real_u_values_buffer(real_u_values)-u(t-1))^2;
            real_cost_values_buffer(real_u_values) = G_y^2*sum((Xj).^2)+ (G_u*(real_u_values_buffer(real_u_values)-u(t)))^2;
        end
    end

%STEP 7: Choose u*(t) as the root which produced the lowest function cost
    u_best = 0;
    for  i = 1:max(size(real_cost_values_buffer))
        if min(real_cost_values_buffer) == real_cost_values_buffer(i)
            u_best = real_u_values_buffer(i);
        end
    end

%STEP 8: Apply u*(t) to the physical system
    u = [u, u_best];
    
    % Apply to 'real' system
    %yoff = VoltSys(u, h1, h2);
    
    %yoff = filter(b1,a1,u) + (filter(b2,a2,u)).^2 + normrnd(0,std,1,length(u)) + disturbance;
    
    x1 = [x1, A1*x1(:, t) + B1*u_best];
    x2 = [x2, A2*x2(:, t) + B2*u_best];
    %Check control
    %if output is the same as 20 samples ago, cut out of control.
    if t> 20
%         if (mean(yoff(t-20:t)) < ref(t)+0.0002) && (mean(yoff(t-20:t)) > ref(t)-0.0002)
%            control = 0; 
%         end
    end
    if t >= 500
        control = 0; 
    end
    
    %Increase time increment
    t=t+1
    
    %Update Disturbance
%     disturbance = yoff(t)-alpha0_v - ;
end


plot(ref)
hold on
plot(u);
hold on
% Find output from modelled sys
y2 = VoltSysLag(a, u, alpha1', alpha2', ML);
plot(y2);
legend('ref(t)','u(t)','y(t)');
title('MPC Control of Modelled System');
xlabel('Samples [k], Ts = 15sec');
ylabel('Voltage Level (V)')

% y1 = VoltSysTime(u, h1, h2, n, n);
% plot(y1);
function [u, y, y0] = DataCollection(N, M, ratio, tresponse, sim)

    if sim == 1
        
%         %SIMUALTION RESULTS
% 
%         %Toy system
%         b1 = [0 0.501];
%         a1 = [1 -1.8036 0.8338];
%         b2 = [0 0.7515];
%         a2 = [1 -1.8036 0.8338];
% 
%         %Random input
%         u = normrnd(0,1,1,N);
%         %Time of response
%         t = linspace(0, (N-1), N);
% 
%         %Weiner Structure
%         y0 = filter(b1,a1,u) + (filter(b2,a2,u)).^2; %True output of system
%         e = normrnd(0,0,1,length(y0)); %Measurement error
%         y = y0 + e; %Noisy output of system
%         
%         save('u_const.mat','u');
%         save('y_const.mat','y');
%         save('y0_const.mat','y0');

     % Data sample size
        N = 800;
        load('inout_018.mat');
        [~, v, li] = inout_018.Y.Data;
        y_test = v(1:N)';
        u_test = li(1:N)';
        y = y_test;
        u = u_test;
    %     y = y_test(2:1+N);
    %     u = u_test(2:1+N);
        y0 = y;
        figure();
        subplot(2,1,1);
        plot(u_test);
        ylabel('u[k]')
        subplot(2,1,2);
        plot(y_test);
        ylabel('y[k]')
        else

            %Constant or experimental RESULTS
            load('u_const.mat');
            load('y_const.mat');
            load('y0_const.mat');
    end 
    
    
    if tresponse
        
        %PLOT TIME DOMAIN RESPONSEE
        
        plot(t, y);
    end 

end
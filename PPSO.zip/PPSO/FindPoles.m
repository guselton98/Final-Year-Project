function [pole1D, pole2D] =  FindPoles(h1, h2, plength, dim)
    
    %Find S(1) and S(2) for 1dim kernel
        
    Q = [0,0];
    S = [0,0];
    hnorm = 0;
    %lag 1
    for j = 1:plength-1
            hnorm = hnorm + h1(j)^2;
            S(1) = S(1) + j*h1(j)^2;
            S(2) = S(2) + j*(h1(j+1)-h1(j))^2;
    end
    S(1) = S(1)./hnorm;
    S(2) = S(2)./hnorm;
    Q(1) = mean(S(1));
    Q(2) = mean(S(2));

    pole1D = (2*Q(1)-1-Q(2))/(2*Q(1)-1+sqrt(4*Q(1)*Q(2)-Q(2)^2-2*Q(2)));
    
    %Find S(1) and S(2) for 2dim kernel
        
    Q = [0,0];
    S = zeros(2, plength);
    
    hnorm = sum(h2(:).^2);
    
    for k = 1:dim
        %lag 1
        for j = 1:plength-1
            %lag 2
            for i = 1:plength-1
                S(1, k) = S(1, k) + j*h2(j, i)^2;
                S(2, k) = S(2, k) + j*(h2(j+1, i)-h2(j, i))^2;
            end
        end
    end

    S(1) = S(1)./hnorm;
    S(2) = S(2)./hnorm;
    Q(1) = mean(S(1));
    Q(2) = mean(S(2));

    pole2D = (2*Q(1)-1-Q(2))/(2*Q(1)-1+sqrt(4*Q(1)*Q(2)-Q(2)^2-2*Q(2)));

    %Check boundaries on unit circle and limit pole -1<pole<1
    
    if pole1D < -0.9999
        pole1D = -0.9999;
    end
    
    if pole1D > 0.9999
        pole1D = 0.9999;
    end
    
    if pole2D < -0.9999
        pole2D = -0.9999;
    end
    
    if pole2D > 0.9999
        pole2D = 0.9999;
    end
    
end 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <matrix.h>
#include "mex.h"

//openCL config/setup process based on https://github.com/rsnemmen/OpenCL-examples
#define SOURCE_FILES {"PPSO.cl"}

//Binary file
#define BINARY_FILE "binCache.txt"
#define NUM_FILES 1

/* Swarm SIze and kernel function definition */
#define SWARMSIZE 1
#define SAMPLES 300
#define MEMORY_TIME 70
#define MEMORY_LAGUERRE 12
#define KERNEL_FUNC "PPSO"



#ifdef MAC
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

/* Files */
FILE *fileID;


/* Function definitions */
void SquareMatrixMul(double A[], double B[], double C[], int N);
int CHOL(double A[], double L[], int N);

/* Define Particle Properties - 2nd order only*/
typedef struct
{
	double position[6];
	double pcost;
	double velocity[6];
	double pbest[6];
	double pbcost;
	double prior1[12*12];
	double prior2[78*78];
	double sig[1000*1000];
	double q[1000*1000];
}particle;

/* Data Structure */
/* y[N-n+1], u,v[(M^2+M)/2], PHI[(N-n+1)*(M+(M^2+M)/2)] */


/* Main mex function, called from MATLAB */
void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
	/* Received Data [ul, ll, term, prop, data] */
	double *u_limits, *l_limits, *termCri, *swarmProp;
    u_limits = mxGetPr(prhs[0]);
    l_limits = mxGetPr(prhs[1]);
    termCri = mxGetPr(prhs[2]);
    swarmProp = mxGetPr(prhs[3]);
	
	/* Create mex buffers */
	mxArray *N, *M, *ML, *PHI, *Y, *V, *U;
		
	/* Scalar */
	/* n = data sample size, m = time domain kernel size, ml = laguerre domain kernel size */
	int n, m, ml;
	
	/* Iterative , temprorary variables */
    int i , j, k;
	double temp2;
	
	/* Check particle displacement */
	double rmse;
	double *dimensions;
	int lock;
	double ul_dif = 0;
	dimensions = (double *)malloc(sizeof(double)*6);
	
	/* Extract Scalar sizes needed for malloc and multiplications */
	if (mxIsStruct(prhs[4]))
	{
        N = mxGetField(prhs[4], 0, "n"); 
        n = (int)mxGetScalar(N);
		M = mxGetField(prhs[4], 0, "m"); 
        m = (int)mxGetScalar(M);
		ML = mxGetField(prhs[4], 0, "ml"); 
        ml = (int)mxGetScalar(ML);
		mexPrintf("N = %d \t Time memory legnth = %d \t Laguerre Memory length = %d\n", n, m, ml);
	}
	
	/* Create Pointers */
	cl_double *u, *v, *y, *phi,*L;
	
	/* Assign memory to pointers based on scalars */
	u = (double *)malloc(sizeof(double)*(ml*ml+ml)/2);
	v = (double *)malloc(sizeof(double)*(ml*ml+ml)/2);
	y = (double *)malloc(sizeof(double)*(n-m+1));
	phi = (double *)malloc(sizeof(double)*((n-m+1)*(ml*ml+3*ml)/2));
	//phi = (double *)malloc(sizeof(double)*300*300);
	//L = (double *)malloc(sizeof(double)*300*300);
	
	/* Check malloc */
	if(v == NULL || u == NULL || y == NULL || phi == NULL)
	{
		mexPrintf("Variables [u, v, y, phi] were NOT allocated memory\n");
	}
	else if (mxIsStruct(prhs[4]))
	{
		/* Extract Vectors and copy data from MATLAB mex to C variables*/
        U = mxGetField(prhs[4], 0, "u_coords");
		memcpy(u, (double *)mxGetPr(U), sizeof(double)*(ml*ml+ml)/2);
		
		V = mxGetField(prhs[4], 0, "v_coords");
		memcpy(v, (double *)mxGetPr(V), sizeof(double)*(ml*ml+ml)/2);
		
		Y = mxGetField(prhs[4], 0, "y");
		memcpy(y, (double *)mxGetPr(Y), sizeof(double)*(n-m+1));
		
		PHI = mxGetField(prhs[4], 0, "phi");
		memcpy(phi, (double *)mxGetPr(PHI), sizeof(double)*((n-m+1)*(ml*ml+3*ml)/2));
		
		//PHI = mxGetField(prhs[4], 0, "phi");
		//memcpy(phi, (double *)mxGetPr(PHI), sizeof(double)*300*300);
    }
	
	/* Termination Criteria, term = [maxIter, maxDis, maxCost]; */
	double maxIter, maxDis, maxCost;
	maxIter = termCri[0];
	maxDis = termCri[1];
	maxCost = termCri[2];
	
	/* Extract PSO Information */
	int S, d;
    S = (int)swarmProp[0];
    d = (int)swarmProp[1];
	double C1, C2, inertia;
	C1 = swarmProp[2];
    C2 = swarmProp[3];
	inertia = swarmProp[4];
	
	/* Find size of bytes required */
	size_t S_bytes = sizeof(double)*S;
	size_t d_bytes = sizeof(double)*d;
	
	/* Allocate additional host memory */
	double *h_gb = (double *)malloc(d_bytes);
	double h_gbcost;
	double *pdiff = (double *)malloc(S_bytes);
	double gdiff;
	
	/* Dynamically allocate memory for swarm */
	particle *swarm;
	swarm = (particle *)malloc(S*sizeof(particle));
	
	
	/////////////////////////////////KERNEL SETUP//////////////////////////////////////
	
	/////////////////////////////////PSO INTILIASATION/////////////////////////////////
	
	/* Malloc random variables - both float and double */
	//float *R = (float *)malloc(sizeof(float)*(S*d));
	float *R =  (float *)malloc(sizeof(float)*(2));
	double *r1 = (double *)malloc(sizeof(double)*(S*d));
	double *r2 = (double *)malloc(sizeof(double)*(S*d));
	
	/* Open random generated file */
	fileID = fopen("rand.txt", "r");
	
	/* Initialise position & pbest & velocity */
	for(i = 0; i<S ;i++)
	{
		for(j = 0; j<d ;j++)
		{
			/* Scan random variables from file ... fscanf() uses FLOATS */
			fscanf(fileID, "%f %f", &R[0], &R[1]);
			/* Convert values to double percision - 16 -> 32 bit */
			r1[i+(j*S)] = (double)R[0];
			/* Convert values to double percision - 16 -> 32 bit */
			r2[i+(j*S)] = (double)R[1];
			
			/* Set jth position randomly (lower limit < position <upper limit) */
			swarm[i].position[j] = l_limits[j]+ r1[i+(j*S)]*(u_limits[j]-l_limits[j]);
			
			
			/* Set particels wth random velocities */
			swarm[i].velocity[j] = fabs(u_limits[j]-l_limits[j])/10.0*r1[i+(j*S)];
			swarm[i].velocity[j] = (swarm[i].velocity[j] - fabs(u_limits[j]-l_limits[j])/10.0*r2[i+(j*S)]);
			
		}
	}
	
	swarm[0].position[0] = 1000;
	swarm[0].position[1] = 0.7;
	swarm[0].position[2] = 5000;
	swarm[0].position[3] = 0.7;
	swarm[0].position[4] = 0.7;
	swarm[0].position[5] = 10;
	
	/////////////////////////////////PSO & KERNEL EXECUTION////////////////////////////////////
	
	/* Loop counter */
	double k1 = 0;
	/* Inertia constant */
	double w = 0.7;
	/* Social and Cognitive Acceleration factors */
	double C = 1.2;
	
	/* Flag variables */
	int flag1 = 0; //Raised when position exceeds boundaries
	int flag2 = 1; //Raised when veolicty exceeds boundaries
	int id = 0;
	
	int ml_2 = (ml*ml+ml)/2;
	double temp;
	
	int n_size = n-m+1;
	
	/* FORWARD SUB AND BACK SUB BUFFERS */
	double *x_1;
	double *x_2;
	x_1 = (double *)malloc(sizeof(double)*(n-m+1));
	x_2 = (double *)malloc(sizeof(double)*(n-m+1));
	
	mexPrintf("Samples: %d, Memory Length 1 order: %d, Memory Length 2 order: %d  \n", n, ml, ml_2);
	
	while(flag2){
		
		/* Find cost */
		// [pcost] = PPSO(prior, sig, U, V, Y, PHI, swarm[i].position[j], ml);
		for(id = 0;id<S;id++)
		{
			/* Create Prior One */
			for(i = 0; i < ml; i++)
			{
				for(j = 0; j < ml; j++)
				{
					swarm[id].prior1[i*ml+j] = swarm[id].position[0]*pow(swarm[id].position[1], max(i+1, j+1));
				}
				
				/* Add small tolernace to diagonals-  */
				if(i == j){
					swarm[id].prior1[(i)*ml+(j)] = swarm[id].prior1[(i)*ml+(j)]+0.000001;
				}
			}
				
			/* Create Prior Two */
			for(i = 0; i < ml_2; i++)
			{
				for(j = 0; j < ml_2; j++)
				{
					swarm[id].prior2[(i)*ml_2+(j)] = pow(swarm[id].position[3], max(v[i], v[j]));

					swarm[id].prior2[(i)*ml_2+(j)] = swarm[id].prior2[(i)*ml_2+(j)]*pow(swarm[id].position[4], max(u[i], u[j]));
					
					swarm[id].prior2[(i)*ml_2+(j)] = swarm[id].position[2]*swarm[id].prior2[(i)*ml_2+(j)];
					
					swarm[id].prior2[(i)+(j)*ml_2] = swarm[id].prior2[(i)*ml_2+(j)];
					
					/* Add small tolernace to diagonals: Positive Definiteness  */
					
					if(i == j)
					{
						swarm[id].prior2[(i)*ml_2+(j)] = swarm[id].prior2[(i)*ml_2+(j)]+0.000001;
					}
				}
			}
			
			for(i = 0; i < ml+ml_2; i++)
			{
				for(j = 0; j < n_size; j++)
				{
					/* Reset temporary variable */
					temp = 0;
					
					/* Split Priors: Note that now for loops are minimized from ml+ml_2 to ml and ml_2  */
					
					if(i<ml)
					{
						
						for(k = 0; k < ml; k++)
						{
							temp = temp + swarm[id].prior1[i*ml + k]*phi[j + k*n_size];
						}
						
					}else{
						
						for(k = 0; k < ml_2; k++)
						{
							temp = temp + swarm[id].prior2[(i-ml)*ml_2 + k]*phi[j + (k+ml)*n_size];
						}
						
					}
					
					swarm[id].q[i*n_size + j] = temp;
				}
			}
			
			/* SIG = PHI'*P*PHI + noise_std^2*eye(length(SIG))- Evaluate covariance matrix*/
			for(i = 0; i < n_size; i++)
			{
				for(j = 0; j < n_size; j++)
				{
					temp = 0;
					
					for(k = 0; k < ml+ml_2; k++)
					{
						temp = temp + phi[i + k*n_size]*swarm[id].q[j + k*n_size];
					}
					
					swarm[id].sig[i*n_size + j] = temp;
					if(i == j)
					{
						swarm[id].sig[i*n_size + j] = swarm[id].sig[i*n_size + j] + swarm[id].position[5]*swarm[id].position[5];
					}
				}
			
			}
		
			flag1 = CHOL(swarm[id].sig, swarm[id].q, n_size);
		
			if(!flag1)
			{
				double det = 0;
				for (j = 0; j < n_size; j++) 
				{
					x_1[j] = 0;
					x_2[j] = 0;
				}
				
				//Lx_1 = Y --> back substitution (lower triangle)
				//Solve x_1 = 1/L * Y
				
				for (j = 0; j < n_size; j++) 
				{
					temp = 0;

					for (i = 0; i < j; i++)
					{
						temp = swarm[id].q[j*n_size + i] * x_1[i] + temp;
					}

					x_1[j] = (y[j] - temp) / (swarm[id].q[j * n_size + j]);
				}
				
				//Ux_2 = x_1 --> back substitution (upper triangle)
				//Solve x_2 = 1/U * x_1
				
				for (j = n_size - 1; j >= 0; j--) 
				{
					temp = 0;

					for (i = n_size - 1; i > j; i--)
					{
						temp = swarm[id].q[i*n_size + j] * x_2[i] + temp;
					}

					x_2[j] = (x_1[j] - temp) / (swarm[id].q[i * n_size + i]);
				}
				
				/*
				det = log(det(LU)) == log(det(L)*det(U)) --> det(triangle) = product of diagonals
				det(U) == 1, det(L) ==> log(det(L)*det(U)) == prod(eig(L))
				logdet(prod(eig(L))) == sum(log(diag(L)))
				if U = L', then det(LU) = 2*det(L) 
				*/

				//J = Y'x_2 + det
				temp = 0;
				det = 0;
				for (j = 0; j < n_size; j++) 
				{
					temp = temp + y[j]*x_2[j];
					det = det + log(swarm[id].q[j*n_size+j]);
				}
				swarm[id].pcost = temp+2*det;
			}
			else
			{
				//Illegal cost: set high or set negative, better option would be to return a NAN or INF
				swarm[id].pcost = 200000.00;
			}
			
			/* Update Particles cost if better */
			if(swarm[id].pcost < swarm[id].pbcost || k1 == 0)
			{
				swarm[id].pbcost = swarm[id].pcost;
				
				for (j = 0; j < d;j++) 
				{
					swarm[id].pbest[j] = swarm[id].position[j];
				}
			}
		}
			
	
		/* Evaluate particle best */
		/* Initilialise global best position & cost as 1st particle in 1st iteration */
		if(k1 == 0)
		{
			h_gbcost = swarm[0].pcost;
			for (j = 0; j < d; j++)
			{
				h_gb[j] = swarm[0].position[j];
			}
		}
		
		
		/* Evaluate global best: h_gb and h_gbcost*/
        for(i = 0;i<S;i++)
		{
			/* Find best global position in swarm */
			if(swarm[i].pcost < h_gbcost) 
			{
					for (j = 0; j < d;j++) 
					{
						h_gb[j] = swarm[i].pbest[j];
					}
					
					h_gbcost = swarm[i].pcost;
					
            }
			
			/* Find difference between best known particle costs */
			for(j = 0; j<d ; j++){
				if(j == 0)
				{
					lock = 0;
					dimensions[j] = (swarm[i].position[j]- h_gb[j])*(swarm[i].position[j]- h_gb[j])/(double)S;
				}
				else
				{
					dimensions[j] = dimensions[j] + (swarm[i].position[j]- h_gb[j])*(swarm[i].position[j]- h_gb[j])/(double)S;
				}
			}
        }
		
		k1 = k1+1;
		/* Termination Criterion */
		/* Maximum Iterations */
		
		
		/* Lack of change (cost) */
		for(j = 0; j<d ; j++)
		{
			if(sqrt(dimensions[j]) < maxCost)
			{
				lock = lock + 1;
				mexPrintf("Dimensions %d: %f\n", j, sqrt(dimensions[j]));
			}
		}
		
		if(k1 == maxIter)
		{
			mexPrintf("Reached maximum iterations\n");
			//If maximum iterations are exceeded..i should have a percentage confidence...
			//TODO
			flag2 = 0;
		}
		
		if(lock == d)
		{
			mexPrintf("Particles are pretty close\n");
			//If maximum iterations are exceeded..i should have a percentage confidence...
			//TODO
			flag2 = 0;
		}
		
		/* Linearly Decrease inerrtia constant - w */
		if(flag2)
		{
			if(w>0.6)
			{
				w = 1-k1/100;
			}
			
			/* Continuously Scan rand vars from file --> easiest way to acheive random numbers upon every iteration in C */
			for(i = 0; i<S ;i++)
			{
				for(j = 0; j<d ;j++)
				{
					/* Scan random variables from file ... fscanf() uses FLOATS */
					fscanf(fileID, "%f %f", &R[0], &R[1]);
					/* Convert values to double percision - 16 -> 32 bit */
					r1[i+(j*S)] = (double)R[0];
					/* Convert values to double percision - 16 -> 32 bit */
					r2[i+(j*S)] = (double)R[1];
				}
			}
			
			/* Position and Velocity Updates */
			for(i = 0; i<S; i++)
			{
				for(j = 0; j<d; j++)
				{
					/* Update velocity */
					swarm[i].velocity[j] = w*swarm[i].velocity[j]+C*r1[i+(j*S)]*(swarm[i].pbest[j]-swarm[i].position[j])+C*r2[i+(j*S)]*(h_gb[j]-swarm[i].position[j]);
					
					ul_dif = u_limits[j] - l_limits[j];
					// Checks velocity boundaries
					if(fabs(swarm[i].velocity[j]) > ul_dif/maxDis)
					{
						if(swarm[i].velocity[j] >= 0.0)
						{
							swarm[i].velocity[j] = ul_dif/maxDis;
						}
						else
						{
							swarm[i].velocity[j] = -ul_dif/maxDis;
						}
					}
					
					/* Check position boundaries */
					if((swarm[i].position[j]+ swarm[i].velocity[j]) > u_limits[j])
					{
						/* Bounce velcoity backwards and sewt position to max boundary */
						swarm[i].position[j] = u_limits[j];
						swarm[i].velocity[j] = -swarm[i].velocity[j];
					}
					else if((swarm[i].position[j]+ swarm[i].velocity[j]) < l_limits[j])
					{
						/* Bounce velcoity backwards and sewt position to max boundary */
						swarm[i].position[j] = l_limits[j];
						swarm[i].velocity[j] = -swarm[i].velocity[j];
					}
					else
					{
						/* Update position iff constraints are meet */
						swarm[i].position[j] = swarm[i].position[j] + swarm[i].velocity[j];
					}
				}
			}
		}
	}
	
	/* Return */
	plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
	plhs[1] = mxCreateDoubleMatrix(1, (mwSize)d, mxREAL);
    memcpy(mxGetPr(plhs[0]), &h_gbcost, sizeof(double));
	memcpy(mxGetPr(plhs[1]), h_gb, d_bytes);
	
	/* Free the host from its gloriuos evaluation */
	free(h_gb);
	free(phi);
	free(y);
	free(u);
	free(v);
	free(r1);
	free(R);
	
	// free(test_array);
	
	/* Close files */
	fclose(fileID);
	mexPrintf("MEX Complete. Good Job\n");
}

/* Decomp tests in mex-c */
int CHOL(double A[], double L[], int N){
	
	/* Iterative variables */
	int i, j, k;
	
	/* Set flag 1/0: checks positive definiteness */
	int FLAG = 0;
	
	/* Temporary Summing variable */
	double sumEntries = 0;
	
	/* Create L = zeroes(N) */
	for (i = 0; i < N ; i++)
	{
		for (j = 0; j < N; j++)
		{
			L[i*N+j] = 0;
		}
	}
	
	/* Find L using chol alogrithm*/
	for (j = 0; j < N ; j++)
	{
		for (i = j; i < N ; i++)
		{
			/* Reset SumEntries */
			sumEntries = 0;
			
			/* Check for diagnonal based on chol alg */
			if(i == j)
			{
				//mexPrintf("i: %d j: %d\t", i, j);
				/* Find diagonal component */
				for(k = 0; k < j; k++)
				{
					//mexPrintf("%d\t%d \t", k,j);
					sumEntries = sumEntries + pow(L[j*N+k],2);
				}
				/* Check Flag */
				if( A[i*N+j] < sumEntries)
				{
					/* Raise flag and return error*/
					//mexPrintf("You ffed up : %f\t %f \n", A[i*N+j], sumEntries);
					FLAG = 1;
					return 1;
				}
				
				/* Must not be negative */
				L[i*N+j] = sqrt(A[i*N+j]-sumEntries);
				
			}
			else /* Non Diagonal terms */
			{
				for(k = 0;k<j;k++)
				{
					sumEntries = sumEntries + L[j*N+k]*L[i*N+k];
				}
				
				L[i*N+j] = 1/L[j*N+j]*(A[i*N+j]-sumEntries);
			}
		}
	}
	
	/* Return 0 if complete */
	return 0;
	
}

void SquareMatrixMul(double A[], double B[], double C[], int N){
	
	int i, j, k;
	double temp = 0;
	
	for(i = 0; i < N; i++)
	{
		for(j = 0; j < N; j++)
		{
			temp = 0;
			
			for(k = 0; k < N; k++)
			{
				temp = temp + A[i + k*N]*B[j + k*N];
			}
			
			C[i*N + j] = temp;
		}
	}
}
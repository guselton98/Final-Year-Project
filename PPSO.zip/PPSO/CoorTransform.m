function [u_coords, v_coords] = CoorTransform(n, n2)
    %Rotated coordinate system for 2D kernel
    %V and U coordinate system setup for memory length of M
    u_coords = zeros(1, n2);
    v_coords = u_coords;
    j = n;
    k = 0;
    for i = 2:n2

        u_coords(i) = u_coords(i-1);

        v_coords(i) = v_coords(i-1) + 2;

        if i == j+1
            k = k+1;
            u_coords(i) = u_coords(i) + 1;
            v_coords(i) = k;
            j = j + (n-k);
        end
    end
end

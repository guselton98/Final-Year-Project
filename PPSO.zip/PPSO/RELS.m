function [a1, a2] = RELS(solve, x, PHI, M, m, Y, u_coords, v_coords, pole1, pole2)

    %memory length
    n = M; %for 1st order kernel
    n_2 = (n^2+n)/2; %for 2nd order kernel

    c1 = x(1);          
    lambda1 = x(2);
    c2 = x(3);
    lambda2 = x(4);
    lambda3 = x(5);
    noise_std = x(6); 

    P1 = zeros(n);
    for j = 1:n
        for k = 1:n
            P1(j,k) = c1*lambda1^(max([j k]));
        end
    end

    n2 = (n^2+n)/2;
    P2v = zeros(n2);
    P2u = zeros(n2);

    for i = 1:n2
        for j = i:n2
            P2v(i,j) = lambda2^(max(v_coords(i),v_coords(j)));
            P2v(j,i) = P2v(i,j);
            P2u(i,j) = lambda3^(max(u_coords(i),u_coords(j)));
            P2u(j,i) = P2u(i,j);
        end
    end

    P2 = c2*P2v.*P2u; 
    P = blkdiag(P1, P2);
   % P = P+1e-10*eye(size(P)); %Make sure P is positive definite
    
    if solve == 1
        
        %sigma =0.6^2;
        theta_rels = (P*PHI*PHI'+x(6).*eye(n+n2))^(-1)*P*PHI*Y';
        
        %Seperate 1st order theta values
        a1 = theta_rels(1:n);
        
        %Adjust the linear 2nd order theta values into a 2nd order matrix
        a2 = LKernelAdjustment(2, theta_rels(n+1:end), M);

        afig = figure();
        subplot(1,2,1)
        plot(a1);
        subplot(1,2,2)
        surf(a2);
        set(afig,'Position',[100 100 1200 500]);
        
        %Turn Laguerre values into system values
        h1 = LKernToKer(1, a1, pole1, m);
        h2 = LKernToKer(2, a2, pole2, m);
        
        %figure()
        %plot(y); hold on; plot(y0); legend('y','y0');

        h = figure();
        subplot(1,2,1)
        plot(h1);
        subplot(1,2,2)
        surf(h2);
        set(h,'Position',[100 100 1200 500]);
        title('Final Rep')
    end
    
end
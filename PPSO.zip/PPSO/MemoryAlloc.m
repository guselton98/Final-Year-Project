% Memory space
clc; clear;
ml = 18;
n = 80;
N = 1000;
S = 128;

MAXALLOC = 2.048e9;

% Includes particles properties: new and old data plus the upper and lower
% boundaries
% pos = 6, vel = 6, pbcost = 1, cost = 1, pbbest = 6, r1/r2 = 2
% SwarmMem = 2*(pos+vel+pbcost+pbbest+r1/r2)*S + ub + lb
SwarmMem = 2*(20)*S;

% Mem needed for cost calculation
% CostMem = (P1+P2+Sig+Q)*S
CostMem = (2*(N-n+1)^2+(ml^4+2*ml^3+5*ml^2)/(4))*S;

% Mem needed for common data storage
% DataMem = phi+ucoor+vcoor+Y
DataMem = (ml^2+ml) + (N-n+1)*((ml^2+3*ml+2)/(2));

% Calculatees total bytes, assuming doubles
Total = (SwarmMem+CostMem+DataMem)*32/4;

fprintf('Total Bytes Required:  %e\n', Total);

fprintf('(N^2+N)*S:  %e\n', (2*((N-n+2)^2)*S*32/4));
%%

clc; clear;
syms ml N n S n_size
% Includes particles properties: new and old data plus the upper and lower
% boundaries
% pos = 6, vel = 6, pbcost = 1, cost = 1, pbbest = 6, r1/r2 = 2
% SwarmMem = 2*(pos+vel+pbcost+pbbest+r1/r2)*S + ub + lb
SwarmMem = 2*(20)*S;

% Mem needed for cost calculation
% CostMem = (P1+P2+Sig+Q)*S
CostMem = (2*(n_size)^2+(ml^4+2*ml^3+5*ml^2)/(4))*S;

% Mem needed for common data storage
% DataMem = phi+ucoor+vcoor+Y
DataMem = (ml^2+ml) + (n_size)*((ml^2+3*ml+2)/(2));
simplify((SwarmMem+CostMem+DataMem))
Ts = 15;
load('tank_L20_4th.mat');
% plot(h1); 
% figure();
% surf(h2);

n = length(h1)
[n_2, ~] = size(h2)

% Input step response
input = [3.5*zeros(1,70), 3.5*ones(1,930)];

% Initialise output
output = zeros(1, 1000);


% Output response
for t = 71:1000
    
    % Offset
    order_0 = 0;
    
    % First order response
    order_1 = 0;
    for i = 1:n
        order_1 = order_1+h1(i)*input(t-i);
    end
    
    
     % Second order response
    order_2 = 0;
    for i = 1:n_2
        for j = 1:n_2
            order_2 = order_2+h2(i,j)*input(t-i)*input(t-j);
        end
    end
    
    output(t) = order_0+order_1 + order_2;
    
end

plot(output);
function hsys = LKernToKer(dim, h, pole, plength)
 
    n = min(size(h));
    
    if dim == 1
        n = max(size((h)));
    end 
    
    phi = zeros(n,plength+1);
    
    %Generate filter responses (5.16)
    z = tf('z');
    for k = 1:n
        f = sqrt(1-pole^2)/(z-pole)*((1-pole*z)/(z-pole))^(k-1);
        phi(k,:) = impulse(f,plength);
    end 
        
    %Arrange kernel expansion (5.16)
    if dim == 1
        hsys = zeros(1,plength);
        for j = 1:plength
            for i = 1:n
                hsys(j) = hsys(j) + h(i)*phi(i,j);
            end
        end  
    end 
    
    if dim == 2
        hsys = zeros(plength,plength);
        
        for j = 1:plength
            for k = 1:plength
                for d1 = 1:n
                    for d2 = 1:n
                        hsys(j,k) = hsys(j,k) + h(d1,d2)*phi(d1,j)*phi(d2,k);
                    end
                end
            end
        end  
        
    end
    
end
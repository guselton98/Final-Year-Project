function y = per_excite(u, tau)

    N  = max(size(u));

    R = zeros(tau,tau);
    %Linear
    for i = 1:tau
        
        R(1,i) = 0;
        
        for j = 1:N-tau
            
             R(1,i) =  R(1,i) + u(i)*u(i+j);
             
        end
        
         R(1,i) =  R(1,i)*1/N;
        
    end
    
    for i = 2:tau
        
        for j = i:tau
        
         R(i,j) = R(i-1,j-1);
         
        end
        
    end
    
    % Diagonalise
    for i = 2:tau
        
        for j = i:tau
            
              R(j,i) =   R(i,j);
            
        end
        
    end
    
    %check rank
 
    y = rank(R);
end
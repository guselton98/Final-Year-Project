function y = VoltSysLag(a, u, alpha1, alpha2, ml)

    pole1D = a(1);
    pole2D = a(2);
    [~, N] = size(u);
    y = zeros(1, N);
    
    x1 = zeros(1, N);
    x2 = zeros(1, N);
    
    z = tf('z');
    
    for k = 1:ml
        %Find tranfer function of 1st order filter, f
        f = sqrt(1-pole1D^2)/(z-pole1D)*((1-pole1D*z)/(z-pole1D))^(k-1);
        %Extract coefficients
        [num1,den1] = tfdata(f,'v');
        %Filters inputs, u, through filter f, f+u = fu
        x1(k, :) = filter(num1, den1, u);

        %Find tranfer function of 2nd order filter, g
        g = sqrt(1-pole2D^2)/(z-pole2D)*((1-pole2D*z)/(z-pole2D))^(k-1);
        %Extract coefficients
        [num2,den2] = tfdata(g,'v');
        %Filters inputs, u, through filter g, g+u = gu
        x2(k, :) = filter(num2, den2, u);
    end
    
    for t = 1:N

        % Offset
        order_0 = 0;

        % First order response
        order_1 = 0;

        for i = 1:ml
            order_1 = order_1 + alpha1(i)*x1(i, t);
        end


        % Second order response
        order_2 = 0;
        for i = 1:ml
            for j = 1:ml
                order_2 = order_2 + alpha2(i,j)*x2(i,t)*x2(j,t);
            end
        end

        y(t) = order_0+order_1 + order_2;

    end


end
ML = 2;
u = ones(1, 100);
z = tf('z');
%Store filtered inputs
fu = zeros(ML,max(size(u)));
pole1D = 0.8;

for k = 1:ML
    %Find tranfer function of 1st order filter, f
    f = sqrt(1-pole1D^2)/(z-pole1D)*((1-pole1D*z)/(z-pole1D))^(k-1);
    %Extract coefficients
    [num1,den1] = tfdata(f,'v');
    %Filters inputs, u, through filter f, f+u = fu
    fu(k, :) = filter(num1, den1, u);
end


Y = [1,2,3;4,5,6;7,8,9];
X = Y;
U = ones(3);

Z1 = kron(X+Y,U);
Z2 = kron(X.*U,Y.*U);

A = [5, 2, 3];
B = [1, 6];
conv(u_conv, v_conv)

xj = [1,1,1];
dxj = [2,1];
conv(xj, dxj)
tf(xj, 1)^2

%%
syms z 
a = 0.8
B = sqrt(1-a^2)
F1 = (B)/(1-a*z^(-1))
F2 = F1*(z^(-1)-0.8)/(1-0.8*z^(-1))
F3 = F2*(z^(-1)-0.8)/(1-0.8*z^(-1))
F4 = F3*(z^(-1)-0.8)/(1-0.8*z^(-1))

iztrans(F1)
iztrans(F2)
iztrans(F3)
iztrans(F4)
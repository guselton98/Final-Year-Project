clc; clear;

% Test Results
use_results = 1;
LSsoln = 1;
M = 70;         % Memory length of ReLS
ML = 15;
plot_output = 1; % 0/1: plot time domain output of a noisy system if true
simulate = 1;

if use_results 
    % Data sample size
    N = 800;
    load('exact_model.mat');
%     [~, y_test, u_test] = inductor_data.Y.Data;
    y_test = y(1:N);
    u_test = u(1:N);
    y = y_test;
    u = u_test;
%     y = y_test(2:1+N);
%     u = u_test(2:1+N);
    y0 = y;
    figure();
    subplot(2,1,1);
    plot(u_test);
    ylabel('u[k]')
    subplot(2,1,2);
    plot(y_test);
    ylabel('y[k]')
    
    %[0.118563006849438,0.784904560319706,676.001934134414,1.06588800824938e-05,0.808107750897466,0.934612782031218]
else
    %Requires:
        % control penalty:          R_u
        % initial states:           u(-1)
        % prediction/move horizon:  p/mu
        % Output reference:         ref
        % A and B matrices:         A1 A2 B1 B2 
        % Alpha:                    Laguerre responses

        b1 = [0 0.501];
        a1 = [1 -1.8036 0.8338];
        b2 = [0 0.7515];
        a2 = [1 -1.8036 0.8338];

    % Vec(alpha) %% 

    %Assume alpha0 = 0;
    %Acquire alpha1 and alpha2
    %Steal the code from Main.m...
    %Find laguerre alphas based on aa system with no varance to do control with
    N = 800;        % N = amount of data (Z>0)
    ratio = 3;      % Data sample ratio (Z>0)
    plot_output = 1; % 0/1: plot time domain output of a noisy system if true
    simulate = 1;   % 0/1: (1)simulate , (0)experimental
    std = 20;
    [u, y, y0] = DataCollection(N, M, ratio, plot_output, simulate, std, 0, 0);
end

%%%% DEFINE THE REGULARIZED SIZE OF TIME DOMAIN AND LAGUERRE KERNELS %%%%
% ReLS row dimension size
n = M;          % First order kernel
n2 = (n^2+n)/2; % Second order kernel
% ReLS Laguerre kernel, row dimension size
p = ML;         % First order kernel
p2 = (p^2+p)/2; % Second Order Kernel

%%%% DEFINE LAGUERRE POLES %%%%
%Initial Laguerre poles (-1<pole<1) within a unit circle
pole1D = 0.8;       % First order pole
pole2D = pole1D;    % Second order pole

%%%% FORM SYMETRICAL REGRESSOR MATRIX PHI %%%%
PHI = FormPhi(M, N, u, ML, pole1D, pole2D); %Call FormPhi to evalute regressor matrix
% Persistant Excitation
% test = per_excite(u, 70);



%%%% LEAST SQUARES SOLUTION AND TRUE RESPONSE %%%%
Y = y(n:N);     %Observed output (Causal and dynamic system)
Y0 = y0(n:N);   %True system otuput (Causal and dynamic system)
[~, ~, alpha1, alpha2] = LeastSquares([1, 1], PHI, Y, Y0, n, ML, pole1D); 

alphals1 = alpha1;
alphals2 = alpha2;

%%%% FIND OPTIMAL POLES %%%%
figure();
plot(alpha1);
figure();
surf(alpha2);
[u_coords, v_coords] = CoorTransform(p, p2);

poleCon = [1, 1];
iter = 0;
max_iter = 200;

while abs(max(poleCon-[pole1D, pole2D])) > 0.001
    
    poleCon = [pole1D, pole2D];
    
    tic;
    %PSOfunc - Paralleled minimization method used to tune hyperparameters
    [hparams, cost] = PSOfunc(PHI, ML, Y, u_coords, v_coords, max_iter);
    timer1(iter+1) = toc;
    
    % Evaluate RELS estimated data/plots laguerre and time domain plots
    [alpha1, alpha2] = RELS(1, hparams, PHI, ML, M, Y, u_coords, v_coords, pole1D, pole2D);
    
    h1 = LKernToKer(1, alpha1, pole1D, M);
    h2 = LKernToKer(2, alpha2, pole2D, M);
    
    [pole1D, pole2D] = FindPoles(h1, h2, M, 2);
    PHI = FormPhi(n, N, u, p, pole1D, pole2D); %re-evaluate PHI matrix
    
    iter = iter + 1;
end
max_iter = 1000;

%PSOfunc - Paralleled minimization method used to tune hyperparameters
[hparams, cost] = PSOfunc(PHI, ML, Y, u_coords, v_coords, max_iter);

% Evaluate RELS estimated data/plots laguerre and time domain plots
[alpha1, alpha2] = RELS(1, hparams, PHI, ML, M, Y, u_coords, v_coords, pole1D, pole2D);

h1 = LKernToKer(1, alpha1, pole1D, M);
h2 = LKernToKer(2, alpha2, pole2D, M);

[pole1D, pole2D] = FindPoles(h1, h2, M, 2);
PHI = FormPhi(n, N, u, p, pole1D, pole2D);
%%    
%Plot inidividual alphas of system
% figure(1);
% subplot(1,2,1)
% plot(alpha1); % First order kernel
% subplot(1,2,2)
% surf(alpha2); % Second order kernel
% % set(h,'Position',[100 100 1200 500]);
% title('Laguerre Kernels');


%% MPC with disturbance model
%Pre-determined values
%nice_alpha1 and nice_alpha2 are good results from PSO
load('nice_alpha1.mat')
load('nice_alpha2.mat')
std = 0.01;

pole1D = 0.8594;
pole2D = 0.8594;
ML = 12;

b1 = [0 0.501];
a1 = [1 -1.8036 0.8338];
b2 = [0 0.7515];
a2 = [1 -1.8036 0.8338];

% Form A and B matrices

%Laguerre Memory length
L_ML = ML;      %B_m

%A and B matrices
A1 = zeros(L_ML);
A2 = zeros(L_ML);  
B1 = zeros(L_ML,1);
B2 = zeros(L_ML,1);

%Laguerre Poles
a = [pole1D, pole2D];               %a_m
r = [1-a(1).^2, 1-a(2).^2];         %r_m = 1-a^2

%dimensional order = 2
order = 2;

%FORM A and B State Matrices (10.10) and (10.11)
%Each row
for i = 1:L_ML

    B1(i) = sqrt(r(1))*(-a(1))^(i-1);
    B2(i) = sqrt(r(2))*(-a(2))^(i-1);
    %Each column
    for j = 1:i

        %Each diagonal
        if i == j

             A1(i,j) = a(1);
             A2(i,j) = a(2);

        %Each diagonal - 1     
        elseif j == i-1

            A1(i,j) = r(1);
            A2(i,j) = r(2);

        %Everything else   
        else

            A1(i,j) = (-a(1))^(i-j-1)*r(1);
            A2(i,j) = (-a(2))^(i-j-1)*r(2);

        end

    end

end
        
% alpha row transform vec(.)

alpha0 = 0;     % ASSUME: Zero offset
alpha0_v = alpha0;
alpha1_v = reshape(alpha1, 1, ML);
alpha2_v = reshape(alpha2', 1, ML*ML);

% Initial filtered inputs
u = [0,0,0];
% u = ones(0.5,0.5,0.5);
z = tf('z');
%Store filtered inputs
fu = zeros(ML,max(size(u)));
gu = fu;

%plength: number of filters
for k = 1:ML
    %Find tranfer function of 1st order filter, f
    f = sqrt(1-pole1D^2)/(z-pole1D)*((1-pole1D*z)/(z-pole1D))^(k-1);
    %Extract coefficients
    [num1,den1] = tfdata(f,'v');
    %Filters inputs, u, through filter f, f+u = fu
    fu(k, :) = filter(num1, den1, u);

    %Find tranfer function of 2nd order filter, g
    g = sqrt(1-pole2D^2)/(z-pole2D)*((1-pole2D*z)/(z-pole2D))^(k-1);
    %Extract coefficients
    [num2,den2] = tfdata(g,'v');
    %Filters inputs, u, through filter g, g+u = gu
    gu(k, :) = filter(num2, den2, u);
end

x1 = fu;
x2 = gu;
%Initial disturbance
disturbance = 0;

% Initial outputs
yoff = filter(b1,a1,u) + (filter(b2,a2,u)).^2+ normrnd(0,std,1,length(u));



% Control
G_u = 1;      % G_u (input penatly, Gamma_u)
G_y = 1;      % G_y (output - ref penatly)
p = 20;          % p (prediction horizon)
ref = [0.9*ones(1, 2000)];      % ref (reference tracking: consider constant for now)
mu = 1;         % mu (move horizon)                        
control = 1;    %1/0
j = p/mu;       %Calculate required steps
M = 2;          % dimensions of impulse (exclude 0 order)

gamma = zeros(M+1, j);      % Xj coefficients over all jth time instances
beta = zeros(2*M, j);       % Xj.d/du.Xj coefficients

u_best = 0;                 % u root to give lowest cost
Xj = zeros(1, p);
dXj = zeros(1, p);

% Time increment ([t] -> t != 0, t > 0)
% initial time: t = 1, start control at t = 3
t = 3;
while(control)
    
    Abar1 = eye(size(A1));
    Abar2 = eye(size(A2)); 
    Aj1 = A1;
    Aj2 = A2;
    
    for i=1:j

%STEP 2: COMPUTE Xj polynomial coefficients (10.19 & 10.20)

        % Offset 0th order: CORRECT
        gamma(1, i) = alpha0_v + ...
                        alpha1_v*(Aj1*x1(:,t)) + ...
                        alpha2_v*kron((Aj2*x2(:,t)),(Aj2*x2(:,t))) -...
                        ref(t) + disturbance;

        % 1st order: CORRECT
        gamma(2, i) = alpha1_v*(Abar1*B1) + ...
                        alpha2_v*(kron(Aj2*x2(:, t), Abar2*B2) + kron(Abar2*B2, Aj2*x2(:, t)));

        % 2nd order: CORRECT
        gamma(3, i) = alpha2_v*(kron(Abar2*B2, Abar2*B2)); 
        
        %Xj = gamma(1) + gamma(2).u(t) + gamma(3).u^2(t)
        
%STEP 3: COMPUTE Xj.d/du.Xj coefficients (10.22): CHECKED/CORRECT

        % Extract jth coefficients from gamma, place in decreasing order
        % u_conv = [gamma(3).u^2(t), gamma(2).u(t), gamma(1)]
        u_conv = fliplr(gamma(:, i)');
        
        %v_conv = [2.gamma(3).u(t), 1.gamma(2)]
        v_conv = zeros(1, M);
        
        %Extract values from u and derive: CORRECT
        for k = 1:M
            v_conv(k) = (M-k+1)*u_conv(k);
        end
        
        %Convolve u and v to form beta coefficients
        % beta : [beta(2M-1)..., beta2, beta1 ,beta0]: CHECKED/CORRECT
        beta(:, i) = conv(u_conv, v_conv)';
        
                
%STEP 1: COMPUTE Abar1 and Abar2 ????? - NEED TO DO
        % Assume Abar1 = A1 and Abar2 = A2
        % Change with j somehow below (10.14)
        
%         Abar1 = Abar1 + A1 + eye(size(A1)); 
%         
%         Abar2 = Abar2 + A2 + eye(size(A2));

          Abar1 = Abar1 + Aj1; 
          Abar2 = Abar2 + Aj2;
          Aj1 = Aj1*A1;
          Aj2 = Aj2*A2;
    end
    
    % Arrange coefficients in increasing order (makes it easier finding row...) 
    % beta : [beta0, beta1, beta2,...,beta(2M-1)]
    beta = flip(beta);
    
%STEP 4: Compute coefficients of the minimizer polynomial, row (10.23)
    % let row = SUM(beta_{2M-1, j}) for j=1 to p
    % row : [r0, r1, r2 ... r(2M-1)]
    row = zeros(1, 2*M);
    
    for i = 1:2*M
        
        %r0
        if i == 1
        
            row(i) = sum(beta(i, :)) - G_u^2*u(t-1);
            
        %r1    
        elseif i == 2
        
            row(i) = sum(beta(i, :)) + G_u^2;
            
        %r2,...r(2M-1)
        else
            
            row(i) = sum(beta(i, :));
            
        end
        
    end
    
%STEP 5: Find all roots of minimizer (10.23)
    u_values = roots(fliplr(row));
    if t>50
        disp(real_u_values_buffer)
        disp(u_values)
    end
%STEP 6: Evaluate objective function for all REAL roots (10.12)
    real_u_values = 0;
    
    % Create buffer size to store costs
    for i = 1:max(size(u_values))
        % Evaluate for REAL roots only
        if imag(u_values(i)) == 0
            %Add length to real buffer
            real_u_values = real_u_values+1;
        end
    end
    
    %Create cost and u buffers
    real_cost_values_buffer = zeros(1, real_u_values);
    real_u_values_buffer = zeros(1, real_u_values);
    real_u_values = 0;
    
    
    for i = 1:max(size(u_values))
        % Evaluate for REAL roots only
        if imag(u_values(i)) == 0
            
            real_u_values = real_u_values+1;
            real_u_values_buffer(real_u_values) = u_values(i);
            
%           (10.15 to 10.16): using u*(t)
            for j = 1:p
                Xj(j) = gamma(3, j)*real_u_values_buffer(real_u_values)^2+...
                    gamma(2, j)*real_u_values_buffer(real_u_values)+...
                    gamma(1, j);
            end
            
            %ISSUE: Evaluate cost sum((yoff(t)-ref)^2) == Xj !!!!!!!!!!!!
            %ISSUE: not evaluating u*(t)
            %Assume: u(t) = [1, 1], u*(t) = root
            %in 10.15, u(t) = u*(t), u(t-1) = u(t)
            % Incorrect
%            real_cost_values_buffer = sum((yoff(t)-ref).^2)+ G_u*(real_u_values_buffer(real_u_values)-u(t-1))^2;
            % Correct: 'Open-loop' mpc, use Xj, donot incoprporate y(t) yet...
            real_cost_values_buffer(real_u_values) = G_y^2*sum((Xj).^2)+ (G_u*(real_u_values_buffer(real_u_values)-u(t)))^2;
        end
    end

%STEP 7: Choose u*(t) as the root which produced the lowest function cost
    u_best = 0;
    for  i = 1:max(size(real_cost_values_buffer))
        if min(real_cost_values_buffer) == real_cost_values_buffer(i)
            u_best = real_u_values_buffer(i);
        end
    end

    
    
%STEP 8: Apply u*(t) to the physical system
    u = [u, u_best];
    
    % The real model- output will be delayed and from ADC on DSPACE in future
    yoff = filter(b1,a1,u) + (filter(b2,a2,u)).^2 + normrnd(0,std,1,length(u));
    
    %Recalculate Xj at optimal input
    Cx = gamma(3, 1)*u(t)^2+...
                    gamma(2, 1)*u(t)+...
                    gamma(1, 1);
                
    %Disturbance calcultion to acheive zero offset for incorrect models 
    %ym = filter(b1,a1,u) + (filter(b2,a2,u)).^2 + disturbance;
    disturbance = yoff(t)-Cx-ref(t);
    x1 = [x1, A1*x1(:, t) + B1*u_best];
    x2 = [x2, A2*x2(:, t) + B2*u_best];
    %Check control
    %if output is the same as 20 samples ago, cut out of control.
    if t> 20
        if (mean(yoff(t-20:t)) < ref(t)+0.0002) && (mean(yoff(t-20:t)) > ref(t)-0.0002)
           control = 0; 
        end
    end
    if t >= 100
        control = 0; 
    end
    
    %Increase time increment
    t=t+1;
end

% Check response to original model
N = max(size(u));
check = 1;
sim = 0;
plot_output = 0;

% Call data collection and evaluate y in the true system
[u, y, y0] = DataCollection(N, M, 3, plot_output, sim, 0, check, u);
figure();
subplot(3, 1, 1);
plot(y0);
ylabel('y0')
subplot(3, 1, 2);
plot(yoff);
ylabel('yoff')
subplot(3, 1, 3);
plot(u)
ylabel('u')
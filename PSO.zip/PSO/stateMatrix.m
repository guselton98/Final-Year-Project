function [A, B] = stateMatrix(pole1, pole2)
A = 
end
function y = VoltSysTime(u, h1, h2, n, n_2)
    
    [~, N] = size(u);
    y = zeros(1, N);
    
    for t = 71:N

        % Offset
        order_0 = 0;

        % First order response
        order_1 = 0;

        for i = 1:n
            order_1 = order_1+h1(i)*u(t-i);
        end


        % Second order response
        order_2 = 0;
        for i = 1:n_2
            for j = 1:n_2
            order_2 = order_2+h2(i,j)*u(t-i)*u(t-j);
            end
        end

        y(t) = order_0+order_1 + order_2;

    end

end
function [u, y, y0] = DataCollection(N, M, ratio, tresponse, sim, std, check, u)

    if sim == 1
        
        %SIMUALTION RESULTS
        b1 = [0 0.501];
        a1 = [1 -1.8036 0.8338];
        b2 = [0 0.7515];
        a2 = [1 -1.8036 0.8338];
        %Toy system
%         b1 = [0 0.2];
%         a1 = [1 -1.8036 0.8338];
%         b2 = [0 0.1];
%         a2 = [1 -1.8036 0.8338];

        %Random input
        u = normrnd(0,1,1,N);
%         figure(1)
%         X=fftshift(fft(u,N)); %compute DFT using FFT      
%         fVals=(-N/2:N/2-1)/N; %DFT Sample points        
%         plot(fVals,abs(X));      
%         title('Double Sided FFT - with FFTShift');
%         Apply a filter
 %       u = filter([1, 3],1,u);
        %fft plot
%         figure(2)
%         X=fftshift(fft(u,N)); %compute DFT using FFT      
%         fVals=(-N/2:N/2-1)/N; %DFT Sample points        
%         plot(fVals,abs(X));      
%         title('Double Sided FFT - with FFTShift');
%         Time of response
        t = linspace(0, (N-1), N);
        u = ones(2, 1000);
        %Weiner Structure
        y0 = filter(b1,a1,u) + (filter(b2,a2,u)).^2; %True output of system
        e = normrnd(0,std,1,length(y0)); %Measurement error
        y = y0 + e; %Noisy output of system
        
    end
    
    if check == 1
        %Check MPC contro
        b1 = [0 0.501];
        a1 = [1 -1.8036 0.8338];
        b2 = [0 0.7515];
        a2 = [1 -1.8036 0.8338];
        
        %Time of response
        t = linspace(0, (N-1), N);

        %Weiner Structure
        y0 = filter(b1,a1,u) + (filter(b2,a2,u)).^2; %True output of system
        e = normrnd(0,std,1,length(y0)); %Measurement error
        y = y0 + e; %Noisy output of system
        
    end
    
    if tresponse
        
        %PLOT TIME DOMAIN RESPONSEE
        figure();
        plot(y); hold on; plot(y0); legend('y','y0');
        
    end 

    
end
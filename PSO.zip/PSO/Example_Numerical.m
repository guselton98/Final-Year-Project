%% Obtain Input and Output Data

clc; clear;
N = 1000;

% u = normrnd(0,1,1,N);
% e = normrnd(0,18,1,N);

load('Numerical.mat')

figure();
plot(y)
hold on
plot(y0)
hold on
plot(u, 'r')
title('Data from System');
xlabel('Sample [k]')
ylabel('Magnitude')
legend('y(t)', 'y^0(t)', 'u(t)')

% G0
G0 = 2;

% G1
b1 = [0 0.7568];
a1 = [1 -1.812 0.8578];
G1 = filter(b1,a1,u);

% G2
b2 = [0 1.063];
a2 = [1 -1.706 0.7491];

% G3
b3 = 1.5.*b1;
a3 = 1.5.*a1;

% G2 and G3
G2 = filter(b2,a2,u).^2;
G3 = filter(b3,a3,G2)*1.5;

y0 = G0 + G1 + G2;
y = y0+e;

snr_tot = var(y0)/var(e)

M = 80;
ML = 15;
% ReLS row dimension size
n = M;          % First order kernel
n2 = (n^2+n)/2; % Second order kernel
% ReLS Laguerre kernel, row dimension size
p = ML;         % First order kernel
p2 = (p^2+p)/2; % Second Order Kernel

%%%% DEFINE LAGUERRE POLES %%%%
%Initial Laguerre poles (-1<pole<1) within a unit circle
pole1D = 0.8;       % First order pole
pole2D = pole1D;    % Second order pole

%%%% FORM SYMETRICAL REGRESSOR MATRIX PHI %%%%
PHI = FormPhi(M, N, u, ML, pole1D, pole2D); %Call FormPhi to evalute regressor matrix
% Persistant Excitation
% test = per_excite(u, 70);

%%%% LEAST SQUARES SOLUTION AND TRUE RESPONSE %%%%
Y = y(n:N);     %Observed output (Causal and dynamic system)
Y0 = y0(n:N);   %True system otuput (Causal and dynamic system)
[h10, h20, ~, ~] = LeastSquares1([1, 0], PHI, Y, Y0, n, ML, pole1D); 
figure();
subplot(1,2,1)
plot(h10);
title('TRUE: 1st Order')
xlabel('\tau_{1}')
ylabel('h_1(\tau_{1})')
subplot(1,2,2)
surf(h20);
view([60 -90 45]);
title('TRUE: 2nd Order')
zlabel('h_2(\tau_{1},\tau_{2})')
xlabel('\tau_{1}')
ylabel('\tau_{2}')

[pole1D, pole2D] = FindPoles(h10, h20, M, 2);

[~, ~, alpha10, alpha20] = LeastSquares1([1, 0], PHI, Y, Y0, n, ML, pole1D); 
figure();
subplot(1,2,1)
plot(alpha10);
title('TRUE: 1st Order')
xlabel('i_{1}')
ylabel('\alpha_1(i_{1})')
subplot(1,2,2)
surf(alpha20);
view([60 -90 45]);
title('TRUE: 2nd Order')
zlabel('\alpha_2(i_{1},i_{2})')
xlabel('i_{1}')
ylabel('i_{2}')



%%%% LEAST SQUARES SOLUTION AND NOISY RESPONSE%%%%
[h1ls, h2ls, alphals1, alphals2] = LeastSquares1([0,1], PHI, Y, Y0, n, ML, pole1D); 
figure();
subplot(1,2,1)
plot(h1ls);
title('Time LS: 1st Order')
xlabel('\tau_{1}')
ylabel('h_1(\tau_{1})')
subplot(1,2,2)
surf(h2ls);
view([60 -90 45]);
title('LS: 2nd Order')
zlabel('h_2(\tau_{1},\tau_{2})')
xlabel('\tau_{1}')
ylabel('\tau_{2}')

figure();
subplot(1,2,1)
plot(alphals1);
title('Laguerre LS: 1st Order')
xlabel('i_{1}')
ylabel('\alpha_1(i_{1})')
subplot(1,2,2)
surf(alphals2);
view([60 -90 45]);
title('Laguerre LS: 2nd Order')
zlabel('\alpha_2(i_{1},i_{2})')
xlabel('i_{1}')
ylabel('i_{2}')


%% %%% REGULARIZE %%%%%%%%%%
[u_coords, v_coords] = CoorTransform(p, p2);
%%%% FIND OPTIMAL POLES %%%%
[pole1D, pole2D] = FindPoles(h10, h20, M, 2);
poleCon = [1, 1];
iter = 0;
max_iter = 200;

%
while abs(max(poleCon-[pole1D, pole2D])) > 0.01
    
    poleCon = [pole1D, pole2D];
    
    tic;
    %PSOfunc - Paralleled minimization method used to tune hyperparameters
    [hparams, cost] = PSOfunc1(PHI, ML, Y, u_coords, v_coords, max_iter);
    t1(iter+1) = toc;
    
    % Evaluate RELS estimated data/plots laguerre and time domain plots
    [alpha1, alpha2] = RELS(1, hparams, PHI, ML, M, Y, u_coords, v_coords, pole1D, pole2D);
    
    h1 = LKernToKer(1, alpha1, pole1D, M);
    h2 = LKernToKer(2, alpha2, pole2D, M);
    
    [pole1D, pole2D] = FindPoles(h1, h2, M, 2);
    PHI = FormPhi(n, N, u, p, pole1D, pole2D); %re-evaluate PHI matrix
    
    iter = iter + 1;
end

%% Final rep

max_iter = 1000;

%PSOfunc - Paralleled minimization method used to tune hyperparameters
tic
[hparams, cost] = PSOfunc1(PHI, ML, Y, u_coords, v_coords, max_iter);
t1(4) = toc;

% Evaluate RELS estimated data/plots laguerre and time domain plots
[alpha1, alpha2] = RELS(1, hparams, PHI, ML, M, Y, u_coords, v_coords, pole1D, pole2D);

h1 = LKernToKer(1, alpha1, pole1D, M);
h2 = LKernToKer(2, alpha2, pole2D, M);

[pole1D, pole2D] = FindPoles(h1, h2, M, 2);
PHI = FormPhi(n, N, u, p, pole1D, pole2D);
%% Show Regualrized LBF resposne
clc;clear
load('Numerical_END');

figure();
subplot(1,2,1)
plot(h1);
title('Time ReLS: 1st Order')
xlabel('\tau_{1}')
ylabel('h_1(\tau_{1})')
subplot(1,2,2)
surf(h2);
view([60 -90 45]);
title('Time ReLS: 2nd Order')
zlabel('h_2(\tau_{1},\tau_{2})')
xlabel('\tau_{1}')
ylabel('\tau_{2}')

figure();
subplot(1,2,1)
plot(alpha1);
title('ReLS LBF: 1st Order')
xlabel('i_{1}')
ylabel('\alpha_1(i_{1})')
subplot(1,2,2)
surf(alpha2);
view([60 -90 45]);
title('ReLS LBF: 2nd Order')
zlabel('\alpha_2(i_{1},i_{2})')
xlabel('i_{1}')
ylabel('i_{2}')

%% Validate model for any input

load('Numerical_END');

N = 1000;

u = normrnd(0,1,1,N);
e = normrnd(0,18,1,N);


% G0
G0 = 2;

% G1
b1 = [0 0.7568];
a1 = [1 -1.812 0.8578];
G1 = filter(b1,a1,u);

% G2
b2 = [0 1.063];
a2 = [1 -1.706 0.7491];

% G3
b3 = 1.5.*b1;
a3 = 1.5.*a1;

% G2 and G3
G2 = filter(b2,a2,u).^2;
G3 = filter(b3,a3,G2)*1.5;

y0 = G0 + G1 + G2;
y = y0+e;

snr_tot = var(y0)/var(e)

% Evaluates the time domain response
% y = VoltSysLag(a, u, alpha1, alpha2, ml)
y1 = VoltSysLag([pole1D, pole2D],u,alpha1,alpha2,ML);

plot(y1);
hold on
plot(y0);

%% Validate model for constant (i.e) loaad  some inputs

load('Numerical_Validate');

% Display validation data
figure();
plot(y)
hold on
plot(y0)
hold on
plot(u, 'r')
title('Data from System');
xlabel('Sample [k]')
ylabel('Magnitude')
legend('y(t)', 'y^0(t)', 'u(t)') 

y1 = VoltSysLag([pole1D, pole2D],u,alpha1,alpha2,ML);
y2 = VoltSysLag([pole1D, pole2D],u,alphals1,alphals2,ML);

figure();
plot(y1);
hold on
plot(y0);
title('Validation');
ylabel('Magnitude')
xlabel('Sample [k]')
legend('y ReLS', 'y0'); 



figure();
plot(y2);
hold on
plot(y0);
title('Validation');
ylabel('Magnitude')
xlabel('Sample [k]')
legend('y LS', 'y0'); 

erms = sqrt(sum(y1-y0).^2/N)
erms = sqrt(sum(y2-y0).^2/N)

%% Linear Model - Not sooo great- the system is aferall highly non-linear
clear; clc;
% Load input and output data
load('Numerical_Validate');
% Load linear model
load('Numerical_linearID.mat')
tf2

b = tf2.Numerator;
a = tf2.Denominator;
y3 = filter(b,a,u)+2;

plot(y3)
hold on
plot(y0)
title('Output');
ylabel('Magnitude')
xlabel('Sample [k]')
legend('y LS', 'y0'); 

%% MPC control - RELS params
clc; clear;
load('Numerical_END');

% HARDCODE PARAMS INTO SIMULINK
% Alpha1, alpha2, alpha0, h10, h20

% Find A1 A2 B1 B2 

%Laguerre Memory length
L_ML = ML;      %B_m

%A and B matrices
A1 = zeros(L_ML);
A2 = zeros(L_ML);  
B1 = zeros(L_ML,1);
B2 = zeros(L_ML,1);

%Laguerre Poles
a = [pole1D, pole2D];               %a_m
r = [1-a(1).^2, 1-a(2).^2];         %r_m = 1-a^2

%dimensional order = 2
order = 2;

%FORM A and B State Matrices (10.10) and (10.11)
%Each row
for i = 1:L_ML

    B1(i) = sqrt(r(1))*(-a(1))^(i-1);
    B2(i) = sqrt(r(2))*(-a(2))^(i-1);
    %Each column
    for j = 1:i

        %Each diagonal
        if i == j

             A1(i,j) = a(1);
             A2(i,j) = a(2);

        %Each diagonal - 1     
        elseif j == i-1

            A1(i,j) = r(1);
            A2(i,j) = r(2);

        %Everything else   
        else

            A1(i,j) = (-a(1))^(i-j-1)*r(1);
            A2(i,j) = (-a(2))^(i-j-1)*r(2);

        end

    end

end
% HARDCODE A1 A2 B1 B2
% Select reference and 1/0 for disturbance model
simTime = 500;
signal = [100*ones(1,100), 20*ones(1,100), 70*ones(1,100), 8*ones(1,100), 50*ones(1,100)]';
ref = [(1:500)', signal];
disturbance = [(1:500)', zeros(1,500)'];
d = 1;

% Simulate and extract input, referecne and output
sim('Numerical_MPC');

y = output.signals.values;
u = input.signals.values;

figure()
plot(y)
hold on
plot(signal, 'r')
legend('y(t)','ref(t)')
title('Output')
xlabel('Sample [k], Ts = 1')
ylabel('Magnitude')
axis([0 500 0 125])

figure()
plot(u)
legend('u(t)')
title('Input')
xlabel('Sample [k], Ts = 1')
ylabel('Magnitude')
axis([0 500 -0.4 0.5])
%%
% Distrubance
simTime = 400;
signal = [25*ones(1, 400)]';
ref = [(1:400)', signal];
disturbance = [(1:400)', [zeros(1, 100),-0.1*ones(1, 300)]'];

d = 1;

% Simulate and extract input, referecne and output
sim('Numerical_MPC');

y = output.signals.values;
u = input.signals.values;

figure()
plot(y)
hold on
plot(signal, 'r')
hold on
plot(disturbance)
legend('y(t)','ref(t)')
title('Output')
xlabel('Sample [k], Ts = 1')
ylabel('Magnitude')
axis([0 500 0 125])

figure()
plot(u)
legend('u(t)')
title('Input')
xlabel('Sample [k], Ts = 1')
ylabel('Magnitude')
axis([0 500 -0.4 0.5])
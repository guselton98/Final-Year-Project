SigY = [1, 4, 6; 3, 20, 1; 1 0 2];
in1 = inv(SigY)
[Q,R] = qr(SigY);
in2 = inv(R)*Q'

d1 = det(SigY)
det(Q)
log(prod(diag(R)))

sum(log(abs(diag(R))))

% [L,U] = LUdecomp(SigY);
% det(L)*det(U)
% log(prod(diag(L)))
% eig(SigY)
function [h1, h2, h1_LS, h2_LS] = LeastSquares(solve, PHI, Y, Y0, n, plength, pole)

    if solve(1) == 1
        
        %%%% TRUE OUTPUT Y0 %%%%
        
        THETA_LS = PHI'\Y0'; %THETA_LS = (PHI*PHI')^-1*PHI*Y' = PHI'\Y
        
        %Extract responses and arrange them accordingly
        h1_LS = THETA_LS(1:plength);
        h2_LS = THETA_LS(plength+1:end);
        h2_LS = LKernelAdjustment(2, h2_LS, plength);
        
        %Finite basis function expansion
        h1 = LKernToKer(1, h1_LS, 0.8170, n);
        h2 = LKernToKer(2, h2_LS, 0.8427, n);

    end 
    
    if solve(2) == 1
        
        %%%% LS OUTPUT Y %%%%
        
        THETA_LS = PHI'\Y'; %THETA_LS = (PHI*PHI')^-1*PHI*Y' = PHI'\Y
        
        %Extract responses and arrange them accordingly
        h1_LS = THETA_LS(1:plength);
        h2_LS = THETA_LS(plength+1:end);
        h2_LS = LKernelAdjustment(2, h2_LS, plength);
        
        %Finite basis function expansion
        h1 = LKernToKer(1, h1_LS, pole, n);
        h2 = LKernToKer(2, h2_LS, pole, n);

    end
end
function PHI = FormPhi(n, N, u, plength, pole1D, pole2D)
    %First generate impulse responses from laguerre filters from inputs
    %Iterate for through the new memory length
    z = tf('z');
    %Store filtered inputs
    fu = zeros(plength,max(size(u)));
    gu = fu;
    
    %plength: number of filters
    for k = 1:plength
        %Find tranfer function of 1st order filter, f
        f = sqrt(1-pole1D^2)/(z-pole1D)*((1-pole1D*z)/(z-pole1D))^(k-1);
        %Extract coefficients
        [num1,den1] = tfdata(f,'v');
        %Filters inputs, u, through filter f, f+u = fu
        fu(k, :) = filter(num1, den1, u);
        
        %Find tranfer function of 2nd order filter, g
        g = sqrt(1-pole2D^2)/(z-pole2D)*((1-pole2D*z)/(z-pole2D))^(k-1);
        %Extract coefficients
        [num2,den2] = tfdata(g,'v');
        %Filters inputs, u, through filter g, g+u = gu
        gu(k, :) = filter(num2, den2, u);
    end
    %PHI will be constructed by PHI = [PHI_1st; PHI_2nd]
    %PHI = zeros(1st order length + 2nd order length, N-n+1);
    PHI = zeros(plength+(plength^2+plength)/2, N-n+1);
    
    %Find PHI_1st = PHI(1:plength, :)
    PHI(1:plength, :) = fu(:,n:N);
    
    %The 2nd order kernel will be arranged to match theta:
    % h(1,1)
    % h(2,2)
    % ...
    % h(1,0)
    % h(2,1)
    % ...
    % h(2,0)
    
    %This pattern is repeated plength times by each row, and n becomes n-i
    %until n = 0. For this reason, n2 = (n^2+n)/2 or n!, which is equal to the
    %number of rows for the 2nd orer dimension.
    %i.e. plength = 3, therefore, n = 3, n2 = 6
    
    %Find 2nd order PHI, PHI_2nd = PHI((plength+1):(plength^2+plength)/2,:)
    %Find the first iteration where n = plength, then build a for loop
    %around that to descirbe n = 1:plength
    %let gu(n)gu(n) == gu(p)gu(q)
    %NOTE: if p==q, PHI = gu*gu else PHI = 2gu*gu 
    
    row = plength + 1;
    
    for repeat = 1:plength
        pmax = plength-repeat+1;
        
        for p = 1:pmax
            q = p+repeat-1;
            
            if repeat == 1
                PHI(row, :) = gu(p,n:N).*gu(q, n:N);
                row = row + 1;
            else
                PHI(row, :) = 2*gu(p,n:N).*gu(q,n:N); 
                row = row + 1;
            end
            
        end
        %1st iteration designated to diagonal components
        
    end 
    
end 
%% Kronecker Check

% Evaluetes the kronecker product [xm(t)]^Kro(m)

%  KM(X1, X2, X3, X4 ..., XM) = [X]^(kro(M)

x1 = [3, 0, 5; 2, 5, 8; 2, 1, 7];

% it works :)
 kron(x1, x1)
 
  kron(x1, x1)+ kron(x1, x1)
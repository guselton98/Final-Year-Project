function h = LKernelAdjustment(dim, rels, plength)
    if(dim == 1)
        %In former function- no need to call this function
    end
    
    if(dim == 2)
        %For 2Dim, operation goes as follows for M = 4
        % 1    2    3   4
        % 2    5    6   7
        % 3    6    8   9
        % 4    7    9   10
        %     ==
        % h(0,0)    h(0,1)    h(0,3)   h(0,3)
        % h(1,0)    h(1,1)    h(1,2)   h(1,3)
        % h(2,0)    h(2,1)    h(2,0)   h(3,2)
        % h(3,0)    h(3,1)    h(3,2)   h(3,3)
        %NOTE: that the kernels are symmetrical
        %max(h_num) = 10, for M = 4
    
%         h = zeros(plength);
%         k = 1;
%         add = 0;
%        % 2nd order kernel is plength x plength
%         for diag = 1:plength
%             
%             %length parameter from the diagonal to side of kernel matrix
%             endofkernel = plength-k+1;
%            
%             for h_num = 1:endofkernel
%                 h(h_num, h_num+diag-1) = rels(h_num+add);
% 
%                 %Symmetric matrix: copy information to the opposite side
%                 if h_num ~= diag
%                     h(h_num+diag-1, h_num) = rels(h_num+add);
%                 end
%             end
%             
%             %Clear used memory
%             %rels(1:endofkernel) = [];
%             add = add + endofkernel;
%             %Increase k by one to limit number of entris in eac row from
%             %the diagonal
%             k = k + 1;
%             
%         end
        h = zeros(plength);

        for diagonal = 1:plength
        offset = diagonal-1;
        entries = plength-diagonal+1;
            for i = 1:entries
                h(i,i+offset) = rels(i);
                if(entries~=plength)
                    h(i+offset,i) = rels(i);
                end
            end
            rels(1:entries) = [];
        end
    end
end
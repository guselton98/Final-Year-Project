function [hparams, gbcost] = PSOfunc(PHI, M, Y, u_coords, v_coords, max_iter)

    %Definitions
    fileID = fopen('exp.txt','w');
    %Stop variables
    %Pause between iterations
    time = 1; %0/off 1/on
    pauselength = 0.1;

    %Define number of particles/dimensions
    S = 128; 
    d = 6;

    %Define C1 C2 r1 r2
    C1 = 0;       %--->1.49 works most of the time, except with sharp function like the scfewel
    C2 = 0;       %---. i will need to adapt the accelaration factor
    w = 1;
    r1 = 1;         %DEPENDS ON EACH DIMENSIONS
    r2 = 1;         %FORMULAE??- let them equal rand(0,1)
    % Turns on linear PSO --> allows particles to search the space
    pso_switch = 3;
    %--------------------------------------------------------------------------
    %Define Termination criterion

    %Max iterations
    maxIter = max_iter; %--->optional user define

    %Lack of change (between points)
    maxDis = [0.001, 0.001, 0.001, 0.001, 0.001, 0.001];%--->optional user define

    %lack of change (between particle cost)
    maxCost = 1;    %--->optional user define
    
    %Velocity constraint V_max = (ub-lb)/maxVel;
    maxVel = 5;
    
    %Define limits  %--->user define (depending on what they want)
    dm = 0.99;
    ul = [10e3, dm, 10e3, dm, dm, 10e3];
    ll = [0, 0, 0, 0, 0, 0];
    %Define boundaries
    ub = ul;
    lb = ll;

    %--------------------------------------------------------------------------
    
    %Initialise the Swarm
    %Initialise X and Y(position vector)-- for more dimensions
    pos = ones(S,d);
    %positon matrix
    for i = 1:S
        for j = 1:d

            %set initial conditions for hyperparamters
            if i == 1
                pos(i,1) = 0.001;       %c1
                pos(i,2) = 0.001;     %lambda1
                pos(i,3) = 0.001;       %c2
                pos(i,4) = 0.001;     %lambda2
                pos(i,5) = 0.001;     %lambda3
                pos(i,6) = 1;       %noise_std

            %randomly set other conditions
            else
                pos(i,j) = lb(j)+ rand(1,1)*(ub(j)-lb(j));
            end

        end
    end

    %Set pbest
    pbest = pos;

    %Initialise V
    for i = 1:d
        velocity = sqrt(ub(i))*rand(S,i);
        velocity = velocity - sqrt(ub(i))*rand(S,i);
    end

    %--------------------------------------------------------------------------
    %Evaluate the RELS function to find intial costs
    pbcost(S,1) = 0;

    for i = 1:S
        pbcost(i) = RELSFunc(pos(i,:),PHI, M, Y, u_coords, v_coords);
    end

    [gbcost,index] = min(pbcost);
    gb = pbest(index,:);
    
    % --------------------------------------------------------------------------
    %gcost and gbest
    tic;
    t1 = cputime;
    k = 1;
    lock = zeros(1, d);
    fprintf(fileID,'%s\t %s\t %s\t\n','k', 'gb', 'gbcost');
    while 1
        
        lock = zeros(1, d);
        
        %Iterate for each particle
        for i = 1:S

             %linearly decrease momentum
                if w > 0.7 
                    if k > pso_switch
                        w = 1-(k-pso_switch)/100;
                    end
                end

                %Cognitve after n iterations to increase search area
                if k > pso_switch
                    C1 = 1.2;
                    C2 = 1.2;
                end

            %Iterate each dimension
            for j = 1:d
                r1 = rand(1);
                r2 = rand(1);

                %Update velocity
                velocity(i,j) = w*velocity(i,j)  ...
                    + C1*r1*(pbest(i,j)-pos(i,j)) ...
                    + C2*r2*(gb(j)-pos(i,j));

                % Max velocity speed
                if abs(velocity(i,j)) > (ub(j)-lb(j))/maxVel

                    if velocity(i,j) > 0
                        velocity(i,j) = (ub(j)-lb(j))/maxVel;
                    else
                        velocity(i,j) = -(ub(j)-lb(j))/maxVel;
                    end

                end
                
                %Update and check position
                if pos(i,j) + velocity(i,j) > ub(j)
                    
                    pos(i,j) = ub(j)- 0.000001;
                    velocity(i,j) = -velocity(i,j);
                    
                elseif pos(i,j) + velocity(i,j) < lb(j)
                    
                    pos(i,j) = lb(j) + 0.000001;
                    velocity(i,j) = -velocity(i,j);
                    
                else
                    pos(i,j) = pos(i,j) + velocity(i,j);
                end
                
            end
            
            %Find Cost
            [cost, error] = RELSFunc(pos(i,:),PHI, M, Y, u_coords, v_coords);
            
            %Update std
            pos(i,:) = error;
            
            %Update best known (compare position to see which one is lowest)
            if cost < pbcost(i)
                %pbest = position, pbcost = cost
                pbest(i,:) = pos(i,:);
                pbcost(i) = cost;
                
                if cost < gbcost
                    %gbest = pbest, iff func(pbest) < gcost
                    %repeat for all dimensions
                    gbcost = cost;
                    
                    for j = 1:d
                        gb(j) = pbest(i,j);
                    end
                end
            end  

        end


        %Break while loop if reached maximum iterations
        if k > maxIter
            disp('Reached maximum iterations');
            break
        end

        %Break if particles are not changing by the maxDis margin
%         if max(max(abs(diff(pos(:,:))))) < maxDis
%             disp('Reached minimum due to lack of change in position');
%             break
%         end

        for j = 1:d
            if sqrt(sum((pos(:,j)-gb(j)).^2/S)) < maxDis(j)
               fprintf('Dimension %d = %f \n', j, sum((pos(:,j)-gb(j)).^2/S));
                lock(j) = 1;
            end
        end
        
        if sum(lock) == d 
            disp('Min Var Reached');
            break
        end
    
        %Break if the particles best cost does not change by maxCost margin
%         if (max(pbest(:,:))- min(pbest(:,:))) < maxCost
%             disp('Reached minimum due to lack of change in cost');
%             break
%         end
        fprintf(fileID,'%f\t %f\t %f\t %f\t %f\t %f\t %f\t %f\t \n',k, gb(:), gbcost);
        k = k+1;

        
    end
    toc
    
    hparams = gb(:)

    fclose(fileID);

end
function RELS_Response(a1, a2)

    %Impulse input
    u1 = zeros(1,100);
    u1(1) = 1;
    
    %Filtered input- apply laguerre filters
    
    %y(t) = h(t)*u(t) == a(t)*uf(t)
    
    t = linspace(0, (100-1), 100);    
    plot(t, y)
end
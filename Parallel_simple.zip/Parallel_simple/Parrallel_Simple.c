/* Hardware Setup was developed based off Morris Vysma's mexCL.c file, 2019 */
/* Definitions may be found @ www.Khronos.org */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <matrix.h>
#include "mex.h"

//openCL config/setup process based on https://github.com/rsnemmen/OpenCL-examples
#define SOURCE_FILES {"PSO.cl"}

//Binary file for??
#define BINARY_FILE "binCache.txt"
#define NUM_FILES 1
#define KERNEL_FUNC "PSO"

#ifdef MAC
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

/* Files */
FILE *fileID;

//MAKE A PARTICLE STRUCTURE...
typedef struct
{
	cl_double position[6];		
	cl_double velocity[6];
	cl_double pbest[6];
	cl_double pcost;
}foo;

void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
	/*Inputs*/
    double *lb, *ub, *T, *prop;
    lb = mxGetPr(prhs[0]);
    ub = mxGetPr(prhs[1]);
    T = mxGetPr(prhs[2]);
    prop = mxGetPr(prhs[3]);
	
	/*Termination Criterion - make it easier to read - extract info*/
	double maxIter, maxDis, maxCost;
	maxIter = T[0];
	maxDis = T[1];
	maxCost = T[2];
	
	double dimension_TOL[6] = {maxCost, maxCost, maxCost, maxCost, maxCost, maxCost};
	
    /* Extract dimesion and swarm size */
    int S, d;
    S = (int)prop[0];
    d = (int)prop[1];
	
    /* Iterative variables */
    int i , j, temp = 0;
    
    /* Find space required */
    size_t S_bytes = sizeof(double)*S;
	size_t d_bytes = sizeof(double)*d;
	
	/* Allocate Host Memory */
	foo *particle;
	particle = (foo*)malloc(S*sizeof(foo));
	double *h_gb = (double *)malloc(d_bytes);
	double *pdiff = (double *)malloc(S_bytes);
	double h_gbcost;
	double gdiff;
	
	//openCL Device memory "cl_mem"
	/* Declare particle input/output buffers */
	cl_mem d_old;  
	cl_mem d_new;
	cl_mem d_gb;
	/* Declare boundaries */
	cl_mem d_ub;
	cl_mem d_lb;
	/* Declare random numbers */
	cl_mem d_r1;
	cl_mem d_r2;
	
	/* Declare kernel and other device setup */
	cl_platform_id cpPlatform;        	// OpenCL platform
	cl_device_id device_id;           	// device ID
	cl_context context;               	// context
	cl_command_queue queue;          	// command queue
	cl_program program1, program2;    	// program
	cl_kernel kernel;					// kernel
	cl_int err;							// error command
	
	/* Define local and global sizes - will depend on swarm size and cores of GPU */
	size_t localSize, globalSize;
	//Needs optimizing
	localSize = 32;
	globalSize =(size_t)ceil((int)S/(float)localSize)*localSize;  
	
	//Hardware Setup
	if(1){
        
		char* deviceInfo;
		size_t infoSize;
		/* Platform Setup */
		err = clGetPlatformIDs(1, &cpPlatform, NULL); 
		if(err != CL_SUCCESS ) {
			mexPrintf("Couldn't identify a platform");
			return;
		}
        
		/* ID of device */
		err = clGetDeviceIDs(cpPlatform, CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);
		if(err == CL_DEVICE_NOT_FOUND) {
			/* If error setup for CPU */
			err = clGetDeviceIDs(cpPlatform, CL_DEVICE_TYPE_CPU, 1, &device_id, NULL);
		}
        
		/* Print device ID*/
		clGetDeviceInfo(device_id, CL_DEVICE_NAME, 0, NULL, &infoSize);
		deviceInfo = (char*) malloc(infoSize);
		clGetDeviceInfo(device_id, CL_DEVICE_NAME, infoSize, deviceInfo, NULL);
		printf("Device: %s\n", deviceInfo);
		free(deviceInfo);
        
		/* Check for any errors */
		if(err != CL_SUCCESS ) {
			mexPrintf("Couldn't access any devices");
			return;   
		}
		
		/* Create a context */
		context = clCreateContext(0, 1, &device_id, NULL, NULL, &err);
		
		/* Get source file...PSO.cl */
		FILE *source_handle,*binary_handle;
		char *source_buffer[NUM_FILES], *source_log, *binary_buffer, *binary_log;
		size_t source_size[NUM_FILES], log_size, binary_size;
		const char* source_files[]=SOURCE_FILES;
        
		/* Read each program file and place content into buffer */
		for (int i = 0; i < NUM_FILES; i++) {
			source_handle = fopen(source_files[i], "r");
			if(source_handle == NULL) {
				mexPrintf("Couldn't find the source file");
				return;
			}
			fseek(source_handle, 0, SEEK_END);
			source_size[i] = ftell(source_handle);
			rewind(source_handle);
			source_buffer[i] = (char*)malloc(source_size[i]+1);
			source_buffer[i][source_size[i]] = '\0';
			fread(source_buffer[i], sizeof(char), source_size[i], source_handle);
			fclose(source_handle);
		}
		
		/* SETUP KERNEL */
		/* Create a command Queue */
		queue = clCreateCommandQueue(context, device_id, 0, &err);
		if(err != CL_SUCCESS ) {
			mexPrintf("Couldn't create a command queue\n");
			return;
		}
		
		/* Create program from source buffer */
		program1 = clCreateProgramWithSource(context, NUM_FILES, (const char**)&source_buffer, source_size, &err);
		if(err != CL_SUCCESS ) {
			mexPrintf("Couldn't create the program from source");
			return;
		}
		
		for (int i = 0; i < NUM_FILES; i++) {
			free(source_buffer[i]);
		}
		
		/* Build program executable */
		err=clBuildProgram(program1, 0, NULL, NULL, NULL, NULL);
		if(err != CL_SUCCESS ) {
            
			/* Find size of log and print to std output */
			mexPrintf("Build from source error\n");
			clGetProgramBuildInfo(program1, device_id, CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);
			source_log = (char*) malloc(log_size + 1);
			source_log[log_size] = '\0';
			clGetProgramBuildInfo(program1, device_id, CL_PROGRAM_BUILD_LOG, log_size + 1, source_log, NULL);
			source_log[log_size] = '\0';
			mexPrintf("%s\n", source_log);
			//free(source_log);
			return;
		} 
		
		/* Create Binary File */
		FILE *binFile;
		char *binary;
		clGetProgramInfo(program1, CL_PROGRAM_BINARY_SIZES, sizeof(size_t), &binary_size, NULL);
		binary = (char*)malloc(binary_size);
		clGetProgramInfo(program1, CL_PROGRAM_BINARIES, binary_size, &binary, NULL);
		binFile = fopen(BINARY_FILE, "w");
		fwrite(binary, binary_size, 1, binFile);
		fclose(binFile);
		free(binary);
        
		//read the cache
		binary_handle = fopen(BINARY_FILE, "r");
		if(binary_handle == NULL) {
			mexPrintf("Couldn't find the binary file");
			return;
		}
		
		fseek(binary_handle, 0, SEEK_END);
		binary_size = ftell(binary_handle);
		rewind(binary_handle);
		binary_buffer = (char*)malloc(binary_size+1);
		binary_buffer[binary_size] = '\0';
		fread(binary_buffer, sizeof(char), binary_size, binary_handle);
		fclose(binary_handle);
		program2 = clCreateProgramWithBinary(context, 1, &device_id, &binary_size,(const unsigned char **)&binary_buffer, &binary_log, &err);
		free(binary_buffer);
		err=clBuildProgram(program2, 1, &device_id, NULL, NULL, NULL);
		if(err != CL_SUCCESS ) {
			mexPrintf("Build from cache error\n");
			return;
		}
	}
	/* Loop variable for PSO*/
	double k = 0;
	
	/* Create kernel compute */
	kernel = clCreateKernel(program2, "PSO", &err);
	if(err != CL_SUCCESS ){mexPrintf("create kernel\n"); return;}
	
	//BUFFERS - ALL "cl_mem" variables MUST have a BUFFER !! - analogous to malloc() in C.
	//Buffers declare the size of the device variable 
	//And specifies which can be writen and read from
	
	/* Create input particle buffer*/
	d_old = clCreateBuffer(context, CL_MEM_READ_ONLY , S*sizeof(foo), NULL, NULL);
	/* Create output particle buffer*/
	d_new = clCreateBuffer(context, CL_MEM_WRITE_ONLY , S*sizeof(foo), NULL, NULL);
	/* Create global best position */
	d_gb = clCreateBuffer(context, CL_MEM_READ_ONLY , d_bytes, NULL, NULL);
	/* Create boundary buffer*/
	d_ub = clCreateBuffer(context, CL_MEM_READ_ONLY , d_bytes, NULL, NULL);
	d_lb = clCreateBuffer(context, CL_MEM_READ_ONLY , d_bytes, NULL, NULL);
	/* Create random number buffer */
	d_r1 = clCreateBuffer(context, CL_MEM_READ_ONLY , S_bytes*d, NULL, NULL);
	d_r2 = clCreateBuffer(context, CL_MEM_READ_ONLY , S_bytes*d, NULL, NULL);
	
	//The following command lets you copy 'host' data and paste it into device memory for proccessing
	//Make sure the size is the amount you want to copy.
	
	/* Write constant host memory to inputs of the device */
	err = clEnqueueWriteBuffer(queue, d_ub, CL_TRUE, 0, d_bytes, ub, 0, NULL, NULL);
	err = clEnqueueWriteBuffer(queue, d_lb, CL_TRUE, 0, d_bytes, lb, 0, NULL, NULL);
	
	//Kernel is esssentially a function in C language
	//Below is how you would set arguments for the kernel
	//A kernel is used over a function as you can easily call upon many cores of the GPU for proccessing
	
	/* Set Arguments for kernel */
	err = clSetKernelArg(kernel, 0, sizeof(cl_mem), &d_old);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 0\n"); return;}
	err = clSetKernelArg(kernel, 1, sizeof(cl_mem), &d_new);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 1\n"); return;} 
	err = clSetKernelArg(kernel, 2, sizeof(cl_mem), &d_gb);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 2\n"); return;} 
	err = clSetKernelArg(kernel, 3, sizeof(cl_mem), &d_ub);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 3\n"); return;}
	err = clSetKernelArg(kernel, 4, sizeof(cl_mem), &d_lb);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 4\n"); return;}
	err = clSetKernelArg(kernel, 5, sizeof(cl_mem), &d_r1);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 5\n"); return;}
	err = clSetKernelArg(kernel, 6, sizeof(cl_mem), &d_r2);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 6\n"); return;}
	err = clSetKernelArg(kernel, 7, sizeof(double), &k);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 7\n"); return;}
	err = clSetKernelArg(kernel, 8, sizeof(int), &S);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 8\n"); return;}
	err = clSetKernelArg(kernel, 9, sizeof(int), &d);
	if(err != CL_SUCCESS ){mexPrintf("Failure arg 9\n"); return;}
	
	
	//Random numbers have been generated in MATLAB
	//File was created and now will be scanned to obtain random numbers
	//fscanf() works only with float values (16 bit)
	//Will need to convert to double using (double)
	//Free memory once float values have been converted
	//I could've scanned all values at once but the size depends on maxIter
	//It would of costed a lot of memory for no reason and take a fair amnount of time to process
	/* Malloc random variables - both float and double */
	//float *R = (float *)malloc(sizeof(float)*(S*d));
	float *R =  (float *)malloc(sizeof(float)*(2));
	double *r1 = (double *)malloc(sizeof(double)*(S*d));
	double *r2 = (double *)malloc(sizeof(double)*(S*d));
	   
    /* Malloc random variables - both float and double */
	// float *R = (float *)malloc(sizeof(float)*(S*d));
	// double *r = (double *)malloc(sizeof(double)*(S*d));
	
	/* Open random generated file */
	fileID = fopen("rand.txt", "r");
	
	/* Intialise position/pbest - should be put inside kernel */
	for(i = 0; i<S ;i++){
		for(j = 0; j<d ;j++){
			/* Scan random variables from file ... fscanf() uses FLOATS */
			fscanf(fileID, "%f %f", &R[0], &R[1]);
			/* Convert values to double percision - 16 -> 32 bit */
			r1[i+(j*S)] = (double)R[0];
			/* Convert values to double percision - 16 -> 32 bit */
			r2[i+(j*S)] = (double)R[1];
			particle[i].position[j] = lb[j]+ r1[i+(j*S)]*(ub[j]-lb[j]);
			particle[i].pbest[j] = particle[i].position[j];
			
			/* Set particels wth random velocities */
			particle[i].velocity[j] = fabs(ub[j]-lb[j])/10.0*r1[i+(j*S)];
			particle[i].velocity[j] = (particle[i].velocity[j] - fabs(ub[j]-lb[j])/10.0*r2[i+(j*S)]);
		}
	}
	
	/* Loop PSO */
	while(1){
		
		/* Repeat for the size of the swarm */
		for(i = 0; i<S; i++){
			
			/* Repeat for the dimension size */
			for(j = 0; j<d; j++){
				/* Scan random variables from file ... fscanf() uses FLOATS */
				fscanf(fileID, "%f %f", &R[0], &R[1]);
				/* Convert values to double percision - 16 -> 32 bit */
				r1[i+(j*S)] = (double)R[0];
				/* Convert values to double percision - 16 -> 32 bit */
				r2[i+(j*S)] = (double)R[1];
			}
		}
		
		/* Write structure into input in device memory */
		err = clEnqueueWriteBuffer(queue, d_r1, CL_TRUE, 0, S_bytes*d, r1, 0, NULL, NULL);
		err = clEnqueueWriteBuffer(queue, d_r2, CL_TRUE, 0, S_bytes*d, r2, 0, NULL, NULL);
		err |= clEnqueueWriteBuffer(queue, d_gb, CL_TRUE, 0, d_bytes, h_gb, 0, NULL, NULL);
		err |= clEnqueueWriteBuffer(queue, d_old, CL_TRUE, 0, S*sizeof(foo), particle, 0, NULL, NULL);
		err |= clSetKernelArg(kernel, 7, sizeof(double), &k);
		if(err != CL_SUCCESS ){mexPrintf("Writing Failure\n"); break;}
		
		/* Execute Kernel */
		err = clEnqueueNDRangeKernel(queue, kernel, 1, NULL, &globalSize, &localSize,0, NULL, NULL);
		if(err != CL_SUCCESS ){mexPrintf("Execute Failure\n"); break;}
		/* Wait for queue before reading results back in */
		clFinish(queue);
		
		/* Read Results */
		err = clEnqueueReadBuffer(queue, d_new, CL_TRUE, 0, S*sizeof(foo), particle, 0, NULL, NULL );
		if(err != CL_SUCCESS ){mexPrintf("Read Failure\n"); break;}
		
		/* Find Globals and Termination Specs*/ 
		
		dimension_TOL[0] =0;
		dimension_TOL[1] =0;
		dimension_TOL[2] =0;
		dimension_TOL[3] =0;
		dimension_TOL[4] =0;
		dimension_TOL[5] =0;
		
        for(i = 0;i<S;i++){
			
			/* Intilialise global best as 1st particle in 1st iteration*/
			if( (i == 0) && (k == 0) )
			{
				h_gbcost = particle[i].pcost;
				for (j = 0; j < d; j++)
				{
					h_gb[j] = particle[i].position[j];
				}
				mexPrintf("Intilialise global best as 1st particle in 1st iteration: %f\n", h_gbcost);
			/* Find best global position in swarm */
			}else if(particle[i].pcost < h_gbcost) 
			{
				h_gbcost = particle[i].pcost;
                for (j = 0; j < d;j++) 
				{
                    h_gb[j] = particle[i].pbest[j];
                }
            }
        }
		
		for(i = 0;i<S;i++){
			/* Find difference between particle and best known */
			for(j = 0; j<d ; j++){
				gdiff = particle[i].position[j] - h_gb[j];
				dimension_TOL[j] = dimension_TOL[j] + gdiff*gdiff/(double)S;
			}
			
		}
		gdiff = 0;
		
		for(j = 0; j<d ; j++)
		{
			
			if(sqrt(dimension_TOL[j]) < maxCost)
			{
				gdiff = gdiff + 1;
				mexPrintf("Dimension %d : %f\n", j, sqrt(dimension_TOL[j]));
			}
		}
		
		k = k+1;
		
		/* Termination Criterion*/
        
		/* Maximum Iterations */
		if(k == maxIter){
			mexPrintf("Reached maximum iterations\n");
			break;
		}
		/* Lack of change (cost) */
		if(gdiff == d){
			mexPrintf("Stopped due to lack of change in particles\n");
			break;
		}
		
	}
	 
	/* Release device memory */
	clReleaseMemObject(d_new);
	clReleaseMemObject(d_old);
	clReleaseMemObject(d_ub);
	clReleaseMemObject(d_lb);
	clReleaseMemObject(d_gb);
	clReleaseMemObject(d_r1);
	clReleaseMemObject(d_r2);
	
	/* Release program */
	clReleaseProgram(program1);
	clReleaseProgram(program2);
	clReleaseKernel(kernel);
	clReleaseCommandQueue(queue);
	clReleaseContext(context);
	
	/* Output parameters */
    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
	plhs[1] = mxCreateDoubleMatrix(1, (mwSize)d, mxREAL);
    memcpy(mxGetPr(plhs[0]), &h_gbcost, sizeof(double));
	memcpy(mxGetPr(plhs[1]), h_gb, d_bytes);
	
	/* Release host memory, let the particles free */
	free(particle);
	free(r1);
	free(r2);
	free(R);
	free(pdiff);
	free(h_gb);
	
	/* Print the kth iterations of completion */
	mexPrintf("Finished at %f kth iterations\n", k);
}

//ERROR EVALUATION
/* if(err == CL_INVALID_CONTEXT){
			printf("CL_INVALID_CONTEXT\n");
			}
			if(err == CL_INVALID_DEVICE){
				printf("CL_INVALID_DEVICE\n");
			}
			if(err == CL_INVALID_VALUE){
				printf("CL_INVALID_VALUE\n");
			}
			if(err == CL_INVALID_QUEUE_PROPERTIES){
				printf("CL_INVALID_QUEUE_PROPERTIES\n");
			}
			if(err == CL_OUT_OF_HOST_MEMORY){
				printf("CL_OUT_OF_HOST_MEMORY\n");
			}
			if(err == CL_INVALID_PROGRAM_EXECUTABLE){
				printf("CL_INVALID_PROGRAM_EXECUTABLE");
			}
			if(err == CL_INVALID_COMMAND_QUEUE){
				printf("CL_INVALID_COMMAND_QUEUE\n");
			}
			if(err == CL_INVALID_KERNEL){
				printf("CL_INVALID_KERNEL\n");
			}
			if(err == CL_INVALID_KERNEL_ARGS){
				printf("CL_INVALID_KERNEL_ARGS\n");
			}
			if(err == CL_INVALID_WORK_DIMENSION){
				printf("CL_INVALID_WORK_DIMENSION\n");
			}
			if(err == CL_INVALID_WORK_GROUP_SIZE){
				printf("CL_INVALID_WORK_GROUP_SIZE\n");
			}
			if(err == CL_INVALID_WORK_ITEM_SIZE){
				printf("CL_INVALID_WORK_ITEM_SIZE\n");
			}
			if(err == CL_INVALID_GLOBAL_OFFSET){
				printf("CL_INVALID_GLOBAL_OFFSET\n");
			}
			if(err == CL_OUT_OF_RESOURCES){
				printf("CL_OUT_OF_RESOURCES\n");
			}
			if(err == CL_MEM_OBJECT_ALLOCATION_FAILURE){
				printf("CL_MEM_OBJECT_ALLOCATION_FAILURE\n");
			}
			if(err == CL_INVALID_EVENT_WAIT_LIST){
				printf("CL_INVALID_EVENT_WAIT_LIST\n");
			}
			return; */
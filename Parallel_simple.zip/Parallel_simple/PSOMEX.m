% This file will be used as a user interface to compute a PSO problem
% Initiatilisation processes will be configured in this file
% Random numbers will be generated - global variable
% PSO will be sent to Parrallel.c for evaluation
% File will be created that stores info in C

%INSTRUCTIONS
%Compiling issues
%   ->Cannot create command Queue - restart MATLAB
%   ->Cannot find parrallel.c - change diretory to "Parrallel folder"

% Parrallel.c
%   ->inputs [lb, ub, T, pos]
%   ->outputs [gb, gbcost]

clc; clear;
%--------------------------------------------------------------------------
%PROPERTIES

%Define number of particles/dimensions
S = 128; 
d = 6;
prop = [S, d];

%Define C1 C2 r1 r2, THESE HAVE BEEN FIXED --> CHANGE IN C CODE
C1 = 2;   
C2 = 2;       
w = 1;

%--------------------------------------------------------------------------
%LIMITS
dff = 10;
%Define boundaries --> may be different for each dimension
ub = [dff, dff, dff, dff, dff, dff];
lb = -ub;
%--------------------------------------------------------------------------
%TERMINATION CRITERION

%Max iterations
maxIter = 2000; %---> optional user define
%Lack of change (between points)\

maxDis = 0.0001;%---> optional user define
%Cost constraint
maxCost = 0.0001;    %---> optional user define
T = [maxIter, maxDis, maxCost];

%--------------------------------------------------------------------------
%GENERATE RANDOM NUMBERS: x2 for r1 & r2
R = rand(maxIter*S*2, d);
fileID = fopen('rand.txt','w+');
fprintf(fileID,'%f %f %f %f %f %f\n', R);
fclose(fileID);
%--------------------------------------------------------------------------
%SELECT TEST FUNCTION....
%Todo
%--------------------------------------------------------------------------
%CREATE MEX - Path to openCL compiler
srcFile = 'Parrallel_Simple.c';
ipaths = {['-I' 'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v10.2\include'], ['-L' 'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v10.2\lib\x64'], ['-l' 'OpenCL.lib']};
mex(ipaths{:}, srcFile) 
%Call C function to perform PSO
tic
[gb, gbcost] = Parrallel_Simple(lb, ub, T, prop);
toc
fprintf('Global cost = %f\n', gb);
fprintf('Global position: x(1) = %f,\t x(2) = %f\n', gbcost(1), gbcost(2));


%cost = pow(coor[0]+500,2) + pow(coor[1]-472,2) + 472;
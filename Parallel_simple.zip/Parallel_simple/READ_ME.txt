%INSTRUCTIONS FOR PSOMEX.m FILE

%STEPS
%1)Open PSOMEX.m file in MATLAB R2016b
%2)Check to see whether you are in the correct directory-> located in the 'Parrallel folder'
%3)Select swarm size, dimension of function, boundaries and termination criterion
%4)'Run' the example code
%5)Wait for your result	

%COMPILING ISSUES
%   ->"Cannot create command Queue" - restart MATLAB
%   ->"Cannot find parrallel.c" or pathing related issues - change diretory to the "Parrallel" folder

%FUNCTIONS

% Parrallel.c
%   ->inputs [lb, ub, T, pos]
%   ->outputs [gb, gbcost]

% func()

%%
%PSO.m
%Wikipedia was used to formulate PSO
%FOR ONE DIMESNION FUNCTIONS
%The PSO method does not work in this file however this was the first file
%created to demonstrate the basic concepts and formula of PSO.
%
%The reason why the particle swarm 'explodes' is because there is no
%boundary checking or maximum velocites that the particles can reach.
%Therefore some particles wiol sped up to inifnity and never reach a
%minimum. 
%%
clear; clc;

%DEFINITIONS
%Define number of particles/dimensions/maximum iterations
S = 20; 
d = 1;
iter = 200;
%Define C1 C2 r1 r2
C1 = 2;
C2 = 2;
r1 = 1;         
r2 = 1;  
%velocity weight
K = 1;
phi = 4;
Z = (2*K)/(abs(2-phi-sqrt(phi^2-4*phi)));

%INITIALISATION
%Initialise X (position vector)
X = linspace(-1, 1, S);
%Initialise P (best position vector)
P = X;
%Initialise gbest
gbest = 1000*ones(size(X));
%Initialise V at 0m/s
V = 0*ones(size(X));
%Initialise the swarm
swarm = [X', X', V', gbest'];

%TEST FUNCTION
%using an 'anonymous function'
func = @(x)x.^2;

%Find Initial gbest
for i = 1:S
    if func(swarm(i,2)) <= func(swarm(i,4))
        swarm(:,4) = swarm(i,2);
    end
end


k = 0;

%ITERATE
tic
while 1
    
    %Iterate for each partcle
    for i = 1:S
        
        %Update random variables
        r1 = rand(1);         
        r2 = rand(1);
        
        %Update veloctiy
        swarm(i,3) = Z*(swarm(i,3) + C1*r1*(swarm(i,2)-swarm(i,1))...
            + C2*r2*(swarm(i,4)-swarm(i,1)));
        
        %Update position
        swarm(i,1) = swarm(i,1) + swarm(i,3)/1.1;
        
        %Update best known (compare position to see which one is lowest)
        if func(swarm(i,2)) < func(swarm(i,1))
            swarm(i,2) = swarm(i,1);
            if func(swarm(i,2)) < func(swarm(i,4))
                swarm(i,4) = swarm(i,2);
            end
        end 
        
    end
    
    k = k+1;
     
    %plot function to see the particles move :)
    if k < iter
        plot(swarm(:,2), func(swarm(:,2)), 'b*');
    else
        plot(swarm(:,2), func(swarm(:,2)), 'r*');
        break
    end
    
    hold on
    pause(.01);
end




%% ------------------------------------------------------------------------
%PSOLinear.m
%This file includes previously built code but aims to;
%expand the search of the particles by gradually decreasing the inertia 
%weighting from 1. This will produce a reliable result and cut down on
%iterations for higher order functions such as Shwefel's function.
%This file will work for ANY dimensions as long as the function, dimension
%and boundaries have been specified

%% ------------------------------------------------------------------------
clear; clc;

%USER CONTROL

%opens a save file
fileID = fopen('exp.txt','w');

%Pause between iterations
time = 0; %0/off 1/on
pauselength = 0.1;

%Define number of particles/dimensions
S = 128; 

%!!!!!ONLY SELECT ONE OF THE FOLLOWING TEST FUNCTIONS!!!!!!
%1D Test Function
parabola = 0;

%2D Test Functions 
paraboloid = 0;
Baele  = 0;
Schwefel = 0;
ackley = 0;

%3D Test Functions 
ackley3D = 0;

%6D Test Functions 
ackley6D = 0;
rosen6D = 1;

%!!!!!Set to the dimensions of the test function!!!!!
d = 6;
% ------------------------------------------------------------------------

%PARAMETER SELCTION

%Define C1 C2 and initialise r1 and r2
C1 = 0;       %--->1.49 works most of the time, except with sharp function
C2 = 0;       %---> i will need to adapt the accelaration factor
r1 = 1;        
r2 = 1;  

% Define inertia --> this linearly decreases
w = 1;

% Turns on linear PSO --> allows particles to search the space
pso_switch = 100;
%--------------------------------------------------------------------------

%LIMITS  %--->user define (depending on what they want)

%Set dimenions to +-1000 - optional
% achkely dm = 32.768; lm = 32.768;
%rosen +- 2.048
dm = 2.048; lm = dm;
ul = [dm, dm, dm, dm, dm, dm];       
ll = [-lm, -lm, -lm, -lm, -lm, -lm];    
%Define boundaries
ub = ul;
lb = ll;

%--------------------------------------------------------------------------

%TERMINATION CRITERION

%Max iterations
maxIter = 2000; %--->optional user define

%Lack of change (between points)
maxDis = 0.001;%--->optional user define (variance % confidence)

%Time constraint
maxTime = 20000;    %--->optional user define

%Velocity constraint V_max = (ub-lb)/maxVel;
maxVel = 5;
%--------------------------------------------------------------------------

%INITIALISATION

%Initialise positions for all dimensions
pos = ones(S,1,d);
%Positon matrix
for i = 1:d
    pos(:,:,i) = lb(i)+ rand(S,1)*(ub(i)-lb(i));
end

%Set intial best known position to positions
pbest = pos;
%Initialise gbest - minimum value of the function f([x y z ... n])
gbest = 1000*ones(S,1,d);
%Initialise V
for i = 1:d
    V = sqrt(ul(i))*rand(S,1,i);
    V = V - sqrt(ul(i))*rand(S,1,i);
end

%set swarm[positions, velocities, best positions, best position of swarm]
swarm = ones(S,4,d);
swarm(:,1,:) = pos;
swarm(:,2,:) = V;
swarm(:,3,:) = pbest;
swarm(:,4,:) = gbest;

% Fancy vector plot
old_pos = ones(S,1,d);
new_pos = ones(S,1,d);

%--------------------------------------------------------------------------
%TEST FUNCTIONS AND DISPLAY

if d == 1
     x1 = linspace(ub(1), lb(1), 100);
    if parabola
        func = @(x)(x.^2);
        z = x1.^2;
    end
%     plot(x1, z)
%     hold on
end

if d == 2
    x1 = linspace(ub(1), lb(1), 100);
    y1 = linspace(ub(1), lb(1), 100);
    [x1, y1] = meshgrid(x1,y1);
    if Schwefel
        func = @(x)(d*418.98291-x(:,1)*sin(sqrt(abs(x(:,1))))- ... 
            x(:,2)*sin(sqrt(abs(x(:,2)))));
        z = d*418.98291-x1.*sin(sqrt(abs(x1)))-y1.*sin(sqrt(abs(y1)));
    end
    if Baele
        func = @(x)((1.5-x(:,1)+x(:,1).*x(:,2)).^2 ... 
            +(2.25-x(:,1)+x(:,1).*x(:,2).^2).^2 ... 
            +(2.625-x(:,1)+x(:,1).*x(:,2).^3).^2);
        z = (1.5-x1+x1.*y1).^2+(2.25-x1+x1.*y1.^2).^2+ ... 
            (2.625-x1+x1.*y1.^3).^2;
    end
    if paraboloid
        func = @(x)(x(:,1)^2 + x(:,2)^2);
        z =  x1.^2 + y1.^2;
    end
    if ackley
        func = @(x)(...
            -20*exp(-0.2*sqrt(1/2*(x(:,1).^2+x(:,2).^2)))...
            -exp(1/2*(cos(2*pi*x(:,1))+cos(2*pi*x(:,2))))...
            +20+exp(1)...
            );
        z = -20*exp(-0.2*sqrt(1/2*(x1.^2+y1.^2)))...
            -exp(1/2*(cos(2*pi*x1)+cos(2*pi*y1)))...
            +20+exp(1);
    end
%     mesh(x1,y1,z)
%     hold on
end

% 3rd order...hmm impressive (4th dimensional space)
if d == 3
    if ackley3D
        func = @(x)(...
            -20*exp(-0.2*sqrt(1/d*(x(:,1).^2+x(:,2).^2+x(:,3).^2)))...
            -exp(1/d*(cos(2*pi*x(:,1))+cos(2*pi*x(:,2))+cos(2*pi*x(:,3))))...
            +20+exp(1)...
            );
    end
end

% 6th order == GODDLY
if d == 6
    if ackley6D
        func = @(x)(...
            -20*exp(-0.2*sqrt(1/d*(x(:,1).^2+x(:,2).^2+x(:,3).^2+x(:,4).^2+x(:,5).^2+x(:,6).^2)))...
            -exp(1/d*(cos(2*pi*x(:,1))+cos(2*pi*x(:,2))+cos(2*pi*x(:,3))+cos(2*pi*x(:,4))+cos(2*pi*x(:,5))+cos(2*pi*x(:,6))))...
            +20+exp(1)...
            );
    end
    
    if rosen6D
        func = @(x)(100*(x(:,2)-x(:,1).^2).^2+(x(:,1) - 1).^2 + ...
            100*(x(:,3)-x(:,2).^2).^2+(x(:,2) - 1).^2+...
            100*(x(:,4)-x(:,3).^2).^2+(x(:,3) - 1).^2+...
            100*(x(:,5)-x(:,4).^2).^2+(x(:,4) - 1).^2+...
            100*(x(:,6)-x(:,5).^2).^2+(x(:,5) - 1).^2 ...
            );
    end
end

if d >= 3
    disp('Warning: Too many dimensions to plot')
end

%--------------------------------------------------------------------------
%Iterate

%Find Initial gbest
for i = 1:S
    if func(swarm(i,3,:)) < func(swarm(i,4,:))
        for j = 1:d
            swarm(:,4,j) = swarm(i,3,j);
        end
    end
end

% %Plot initial swarm
% for i = 1:S
%     if d == 1
%         plot(swarm(i,1,1), func(swarm(i,1,1)), 'r.');
%     end
%     if d == 2
%         plot3(swarm(i,1,1), swarm(i,1,2), ...
%                         func([swarm(i,1,1), swarm(i,1,2)]),'r.');
%     end
% end
% 
% if Schwefel
%     title('Paraboloid');
% end
% if Baele
%     title('Baele');
% end
% if paraboloid
%     title('Paraboloid: func = @(x)(x(:,1)^2 + x(:,2)^2)');
% end

tic;
t1 = cputime;
k = 1;
t = 0:1;
fprintf(fileID,'%6s\n','swarm(:,4,j)');

lock = zeros(1, d);

%Evaluate gcost and gbest
while 1
    lock = zeros(1, d);
    %Iterate for each particle
    for i = 1:S
        
        %linearly decrease momentum
        if w > 0.6 
            if k > pso_switch
                w = 1-(k-pso_switch)/100;
            end
        end
        
        %Cognitve after n iterations to increase search area
        if k > pso_switch
            C1 = 1.49;
            C2 = 1.49;
        end
        
        %Iterate each dimension
        for j = 1:d
            r1 = rand(1);
            r2 = rand(1);
            
            %Update velocity
            swarm(i,2,j) = w*swarm(i,2,j)          ...
                + C1*r1*(swarm(i,3,j)-swarm(i,1,j)) ...
                + C2*r2*(swarm(i,4,j)-swarm(i,1,j));
          
            %Update position
            % Max velocity speed
            if abs(swarm(i,2,j)) > (ub(j)-lb(j))/maxVel
                
                if swarm(i,2,j) > 0
                    swarm(i,2,j) = (ub(j)-lb(j))/maxVel;
                else
                    swarm(i,2,j) = -(ub(j)-lb(j))/maxVel;
                end
                
            end
            
            old_pos(i,1,j) = swarm(i,1,j);
            
            if swarm(i,1,j) + swarm(i,2,j) > ub(j)
                %redirect position
                swarm(i,1,j) = ub(j);
                %redirect velocity
                swarm(i,2,j) = -swarm(i,2,j);
            elseif swarm(i,1,j) + swarm(i,2,j) < lb(j)
                %redirect position
                swarm(i,1,j) = lb(j);
                %redirect velocity
                swarm(i,2,j) = -swarm(i,2,j);
            else
                swarm(i,1,j) = swarm(i,1,j) + swarm(i,2,j);
            end
            
            new_pos(i,1,j) = swarm(i,1,j);
            
        end
        
        %Update best known (compare position to see which one is lowest)
        if func(swarm(i,1,:)) < func(swarm(i,3,:))
            
            %pbest = position, iff func(pos) < pcost
            swarm(i,3,:) = swarm(i,1,:);
            if func(swarm(i,3,:)) < func(swarm(i,4,:))
                
                %gbest = pbest, iff func(pbest) < gcost
                %repeat for all dimensions
                for j = 1:d
                    swarm(:,4,j) = swarm(i,3,j);
                end
            end
        end  
        
        %1D plot 
        if d == 1
%             plot(swarm(i,1,1), func(swarm(i,1,1)), 'r.');
        end
        
        %2D plot
%         if d == 2
%             if k < maxIter
% %                 plot3(swarm(i,1,1), swarm(i,1,2), ...
% %                     func([swarm(i,1,1), swarm(i,1,2)]),'r.');
%                 x = old_pos(i,1,1) + (new_pos(i,1,1)-old_pos(i,1,1))*t;
%                 y = old_pos(i,1,2) + (new_pos(i,1,2)-old_pos(i,1,2))*t;
%                 z = func([old_pos(i,1,1), old_pos(i,1,2)]) +(func([new_pos(i,1,1), new_pos(i,1,2)])-func([old_pos(i,1,1), old_pos(i,1,2)]))*t;
%                 %Vector
%                 plot3(x,y,z);
%             else
%                 
%                 %Point
%                 plot3(swarm(i,1,1), swarm(i,1,2), ...
%                     func([swarm(i,1,1), swarm(i,1,2)]),'b.');
%             
%             end
%             hold on
%         end
        
        %3D plot
        %lol good luck
        
    end
    
    %Break while loop if reached maximum iterations
    if k > maxIter
        disp('Reached maximum iterations');
        break
    end
    k = k+1;
    
    %Break if particles are not chnaging by the maxDis margin
%     if max(max(abs(diff(swarm(:,1,:))))) < maxDis)
%         disp('Reached minimum due to lack of change');
%         break
%     end

    for j = 1:d
        if sum((swarm(:,1,j)-swarm(:,4,j)).^2/S) < maxDis
           fprintf('Dimension %d = %f \n', j, sum((swarm(:,1,j)-swarm(:,4,j)).^2/S));
            lock(j) = 1;
        end
    end
    
    if sum(lock) == d 
        break
    end
    % Percentage confidence
%     swarm(:,1,j) < (swarm(:,4,j) + 2.326*(0.1)/sqrt(S)) &&...
%                 swarm(:,1,j) > (swarm(:,4,j) - 2.326*(0.1)/sqrt(S))
    %If time = 1, pause simulation
    if time
        pause(pauselength);
        maxTime = maxTime + pauselength;
    end
    
    
    
    %fprintf(fileID,'%6.2f\n', swarm(:,4,j));
end
toc

%Plot final swarm
% if d == 1
%     plot(swarm(i,1,1), func(swarm(i,1,1)),'b.');
% end
% if d == 2
%     plot3(swarm(i,1,1), swarm(i,1,2), ...
%         func([swarm(i,1,1), swarm(i,1,2)]),'b.');
% end

%Print out information to user
fprintf('Coordinates +1 = %.2d\n', 1+double(swarm(1,4,:)));
fprintf('Function gCost = %.2d\n', func(swarm(1,4,:)));
fprintf('Maximum displacement = %.2d\n', max(max(abs(diff(swarm(:,1,:))))));
fprintf('Number of iterations = %.2d\n', k-1);

error = ones(1,d);
if rosen6D
   for j = 1:d
        error(j) = sqrt(sum(((swarm(:,1,j)-1).^2/S))); 
   end 
end
erms = rms(error)
%% FMINCON 
clc; clear;
d= 2;
dm = 1000;
ul = dm*ones(1, d);       
ll = -dm*ones(1, d);  
% func = @(x)(...
%             -20*exp(-0.2*sqrt(1/d*(x(1).^2+x(2).^2+x(3).^2+x(4).^2+x(5).^2+x(6).^2)))...
%             -exp(1/d*(cos(2*pi*x(1))+cos(2*pi*x(2))+cos(2*pi*x(3))+cos(2*pi*x(4))+cos(2*pi*x(5))+cos(2*pi*x(6))))...
%             +20+exp(1)...
%             );
% func = @(x)(-20*exp(-0.2*sqrt(1/2*(x(1).^2+x(2).^2)))...
%             -exp(1/2*(cos(2*pi*x(1))+cos(2*pi*x(2))))...
%             +20+exp(1));
%         
func =  @(x)((1.5-x(1)+x(1).*x(2)).^2 ... 
            +(2.25-x(1)+x(1).*x(2).^2).^2 ... 
            +(2.625-x(1)+x(1).*x(2).^3).^2);        
        
x0 = ul.*rand(1, d)+ll.*rand(1, d);

tic;
nonlcon = @ack;
[x,fval] = fmincon(func,x0,[],[],[],[],ll,ul)
toc;

function [c,ceq] = ack(x)
    c = [];
    ceq = [];
end
% 1, 2, 3
% 4, 5, 6
% t = 0:1
% x = 1+(4-1)*t
% y = 2+(5-2)*t
% z = 3+(6-3)*t
% plot3(x,y,z)
%{
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PSO is an optimisation algorithm introduced by Kennedy and Eberhart (1995). 
The algorithm minimises the cost function F(x) for lb < x < ub where x is 
an element of real space R^n. This code is based on the variant with 
inertia factor. That is, the velocity is updated by:

    v = w1*v + c1*r1*(PB - x) + c2*r2*(GB - x)                        

Where:
    v is the velocity   
    x is the position
    w1 is the inertia factor
    c1 is the cognitive acceleration
    c2 is the social acceleration
    r1 and r2 are random numbers
    PB is the particle's personal best
    GB is the global best

The algorithm terminates when either of the following conditions have been 
achieved:
    1. Difference between largest and smallest cost of particles is less
       than diffcost.
    2. Difference between position coordinates of adjacent particles is 
       less than diffpos.
    3. Maximum iteration number maxiter reached.

The function accepts the costfunction to be minimised along with any
additional data needed for its evaluation. The function also requires an 
initial position x0 and the lower and upper bounds lb and ub. The function
returns the global best position GB and its associated cost GBcost.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%}

function [GB, GBcost] = PSO(costfunction,lb,ub,x0,data)

%==========================================================================
% Tuning Parameters and Termination Criterion.
%==========================================================================
%---Tuning Parameters---
w1 = 0.7298;            % Inertia factor.            (recommended: 0.7298)
c1 = 1.49618;           % Cognitive acceleration.    (recommended: 1.49618)
c2 = 1.49618;           % Social acceleration.       (recommended: 1.49618)
swarm = 25;             % Number of particles.

%-Termination Criterion-
maxiter = 1000;          % Maximum number of iterations.
diffcost = 1e-3;        % Difference between largest and smallest cost.
diffpos = 1e-6;         % Difference between position coordinates of
                        % adjacent particles.

%==========================================================================
% Memory allocation.
%==========================================================================
dim = length(x0);              % Dimension of search space.
positions(swarm,dim) = 0;      % Positions of swarm particles.    
velocities(swarm,dim) = 0;     % Velocities of swarm particles.
PB(swarm,dim) = 0;             % PB positions of swarm particles.
GB(1,dim) = 0;                 % GB position of all swarm particles.
cost(swarm,1) = 0;             % Cost of current particle positions.
PBcost(swarm,1) = 0;           % Cost of PB positions of particles.
GBcost = 0;                    % Cost of GB position.
index = 0;                     % Used to find the index of best cost.
iterations = 0;                % Iteration count of algorithm.

%==========================================================================
% Initialise positions within feasibility region, PB and GB.
%==========================================================================
% Initialise positions of particles randomly between lb and ub. First 
% particle is initialised to x0.
for i = 1:swarm
    if i == 1
        positions(i,:) = x0(:);
    else
        positions(i,:) = sort(lb + rand(dim,1).*(ub-lb)); % Linear spaced.
        %positions(i,:) = sort(10.^(1 + rand(dim,1)*6));  % Log spaced.  
    end
end

% Calculate corresponding costs of positions.
for i = 1:swarm
    cost(i) = feval(costfunction,positions(i,:),data);
end  

% Calculate personal best and cost (initial PB receives the positions).
PB = positions;
PBcost = cost;

% Calculate global best and cost.
[GBcost,index] = min(PBcost);
GB = PB(index,:);

%==========================================================================
% Start Loop. Update velocities and positions.
%==========================================================================
while 1
    
    velocities = w1*velocities                                      ...
    + c1*repmat(rand(swarm,1),1,dim).*(PB - positions)              ...
    + c2*repmat(rand(swarm,1),1,dim).*(repmat(GB,swarm,1) - positions);
    
    positions = positions + velocities;
    
%==========================================================================
% Check boundaries.
%==========================================================================    
% If particle goes outside of domain bounds it bounces back.
    for i = 1:swarm
        for j = 1:dim
            if positions(i,j) > ub(j)
                positions(i,j) = 2*ub(j)- positions(i,j);
                velocities(i,j) = -velocities(i,j);
                
            elseif positions(i,j) < lb(j)
                positions(i,j) = 2*lb(j)- positions(i,j); 
                velocities(i,j) = -velocities(i,j);
            end
        end
    end

%==========================================================================
% Calculate cost of new positions. Update PB and GB if cost is less.
%==========================================================================
    for i = 1:swarm      
        cost(i) = feval(costfunction,positions(i,:),data);  
        if cost(i) < PBcost(i);
            PBcost(i) = cost(i);
            PB(i,:) = positions(i,:);
        end
        if cost(i) < GBcost,
           GBcost = cost(i);
           GB = positions(i,:);
        end      
    end
   
%==========================================================================
% Check termination criterion.
%==========================================================================  
% Check difference between largest and smallest cost of particles.
    if abs(max(cost)-min(cost)) < diffcost
        disp('Solution found (due to diffcost)')
        iterations
        break;
    end
    
% Check difference between position coordinates of adjacent particles.
    if max(max(abs(diff(positions)))) < diffpos
        disp('Solution found (due to diffpos)')
        iterations
        break;
    end 
    
% Check iteration number.
    if iterations == maxiter
        disp('Solution found (due to maxiter)')
        iterations
        break;
    end 
       
    iterations = iterations+1
    
end

return 

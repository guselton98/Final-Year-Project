%% ------------------------------------------------------------------------
%PSOAdaptive.m
%This file includes previuosly built code but tries and aims to;
%adaptively change the inertia and positon weighting of the PSO algorithm.
%This will reduce the number of particels needed to evaulte the cost
%function and reduce the iterations performed
%Please see the parameter selection document for more adaptive techniques.
%Below utlises 2 types of adaptive tehcniques however one has not been
%implemented and can be seen down the bottom of the code.

%This file will work for ANY dimensions as long as the function, dimension
%and boundaries have been specified

%ADAPTIVE TECH IS NOT WORKING CORRECTLY - NEEDS ADJUSTING
%USE CRTL+C TO STOP CODE

%Update 1...
%When run, the swarm seems to initially expand search, and then drastically
%reduce to one point. This seems to be working, however after it reaches
%this point the particles shoot off towards the limits of the search space.
%ADJUSTED TIME LIMIT- THIS HAS BEEN FAILING....FORMULAE NEEDS WORK

%NOW WORKING - WORKING BETTER THAN PSOLinear.m :)
%% ------------------------------------------------------------------------
clear; clc;

%DEFINITIONS

%Pause between iterations
time = 1; %0/off 1/on
pauselength = 0.1;

%1D Test Function
parabola = 0;
%2D Test Functions 
paraboloid = 1;
Baele  = 0;
Schwefel = 1;

%Define number of particles/dimensions
S = 64; 
d = 2;

%Define C1 C2 r1 r2
C1 = 1.49;           % Cognitive acceleration.    (recommended: 1.49618)
C2 = 1.49;
r1 = 1;         %DEPENDS ON EACH DIMENSIONS
r2 = 1;         %FORMULAE??- let them equal rand(0,1)

%Define initial inertia weight
w = 0.7;
a = 6;
%--------------------------------------------------------------------------
%TERMINATION CRITERION

%Max iterations
maxIter = 200; %--->optional user define

%Lack of change (between points)
maxDis = 10;%--->optional user define

%Time constraint
maxTime = 10000;    %--->optional user define

%Define limits  %--->user define (depending on what they want)
dm = 1000;
ul = [dm, dm, dm, dm, dm, dm, dm, dm];       
ll = [-dm, -dm, -dm, -dm, -dm, -dm, -dm, -dm];    
%Define boundaries
ub = ul;
lb = ll;
%--------------------------------------------------------------------------
%INITIALISATION
%Initialise X and Y(position vector)-- for more dimensions
pos = ones(S,1,d);
pbest = ones(S,1,d);
%positon matrix
for i = 1:d
    pos(:,:,i) = lb(i)+rand(S,1).*(ub(i)-lb(i));
    pbest(:,:,i) = pos(:,:,i);
end

%Initialise gbest - minimum value of the function f([x y z ... n])
gbest = 1000*ones(S,1,d);
%Initialise V
for i = 1:d
    V = sqrt(ul(d))*rand(S,1,d);
    V = V - sqrt(ul(d))*rand(S,1,d);
end

%swarm[positions, velocities, best positions, best position of swarm]
swarm = ones(S,4,d);
swarm(:,1,:) = pos;
swarm(:,2,:) = V;
swarm(:,3,:) = pbest;
swarm(:,4,:) = gbest;
%--------------------------------------------------------------------------
%TEST FUNCTIONS AND DISPLAY

if d == 1
     x1 = linspace(ub(1), lb(1), 100);
    if parabola
        func = @(x)(x.^2);
        z = x1.^2;
    end
    plot(x1, z)
    hold on
end

if d == 2
    x1 = linspace(ub(1), lb(1), 100);
    y1 = linspace(ub(1), lb(1), 100);
    [x1, y1] = meshgrid(x1,y1);
    if Schwefel
        func = @(x)(d*418.98291-x(:,1)*sin(sqrt(abs(x(:,1))))- ... 
            x(:,2)*sin(sqrt(abs(x(:,2)))));
        z = d*418.98291-x1.*sin(sqrt(abs(x1)))-y1.*sin(sqrt(abs(y1)));
    end
    if Baele
        func = @(x)((-1.5-x(:,1)+x(:,1).*x(:,2)).^2 ... 
            +(2.25-x(:,1)+x(:,1).*x(:,2).^2).^2 ... 
            +(2.625-x(:,1)+x(:,1).*x(:,2).^2).^2);
        z = (1.5-x1+x1.*y1).^2+(2.25-x1+x1.*y1.^2).^2+ ... 
            (2.625-x1+x1.*y1.^2).^2;
    end
    if paraboloid
        func = @(x)(x(:,1)^2 + x(:,2)^2);
        z =  x1.^2 + y1.^2;
    end
    mesh(x1,y1,z)
    hold on
end

if d > 2
    disp('Too many dimensions to plot')
end
%--------------------------------------------------------------------------
%PSO

%Find Initial gbest
for i = 1:S
    if func([swarm(i,3,1) swarm(i,3,2)]) <= func(swarm(i,4,:))
        for j = 1:d
            swarm(:,4,j) = swarm(i,3,j);
        end
    end
end

%gcost and gbest
tic;
t1 = cputime;
k = 1;
while 1
    %Iterate for each particle
    for i = 1:S
        
        %Iterate each dimension
        for j = 1:d
            
            %Adaptive inertia weight
            if k <= maxIter/5
                wp = w*1;
            elseif k>maxIter/5
                vari = var(swarm(:,1,j));
                wp = w*exp(-(k-20)^2/(vari));
            end
            
            r1 = rand(1);
            r2 = rand(1);
            %Update velocity
            swarm(i,2,j) = wp*swarm(i,2,j)          ...
                + C1*r1*(swarm(i,3,j)-swarm(i,1,j)) ...
                + C2*r2*(swarm(i,4,j)-swarm(i,1,j));
            
            %Adaptive position weight
            if k<=maxTime
                u2 = 1;
            elseif k>maxTime
                u2 = 1+(k-30)/(a);
            end
            
            %Update position
            swarm(i,1,j) = u2*swarm(i,1,j) + swarm(i,2,j);
            
            if swarm(i,1,j) > ub(j)
                %redirect position
                swarm(i,1,j) = ub(j)- rand(1)*(ub(j)-lb(j));
                %redirect velocity
                swarm(i,2,j) = -swarm(i,2,j)/abs(swarm(i,2,j));
            elseif swarm(i,1,j) < lb(j)
                %redirect position
                swarm(i,1,j) = lb(j)+ rand(1)*(ub(j)-lb(j));
                %redirect velocity
                swarm(i,2,j) = -swarm(i,2,j)/abs(swarm(i,2,j));
            end
        
        end
        
        %Update best known (compare position to see which one is lowest)
        if func(swarm(i,1,:)) < func(swarm(i,3,:))
            
            %pbest = position, iff func(pos) < pcost
            swarm(i,3,:) = swarm(i,1,:);
            if func(swarm(i,3,:)) < func(swarm(i,4,:))
                
                %gbest = pbest, iff func(pbest) < gcost
                %repeat for all dimensions
                for j = 1:d
                    swarm(:,4,j) = swarm(i,3,j);
                end
            end
        end  
        
        %1D plot 
        if d == 1
            plot(swarm(i,1,1), func(swarm(i,1,1)), 'r.');
        end
        
        %plot function to see the particles move (2 dimensions):)
        if d == 2
            if k < maxIter
                plot3(swarm(i,1,1), swarm(i,1,2), ...
                    func([swarm(i,1,1), swarm(i,1,2)]),'r*');
            else
                figure(3)
                plot3(swarm(i,1,1), swarm(i,1,2), ...
                    func([swarm(i,1,1), swarm(i,1,2)]),'b*');
            end
            hold on
        end
        
    end
    
    k = k+1;
    
    %Break while loop if reached maximum iterations
    if k == maxIter
        disp('Reached maximum iterations');
        break
    end
    
    %Break if particles are not chnaging by the maxDis margin
    if max(max(abs(diff(swarm(:,1,:))))) < maxDis
        disp('Reached minimum due to lack of change');
        break
    end
    
    %Time constraint- break if time has exceeded
    t = cputime - t1;
    if t > maxTime
        fprintf('Reached time constraint- t=%.3d\n', t);
        break
    end
    
    %If time = 1, pause simulation
    if time
        pause(pauselength);
        maxTime = maxTime + pauselength;
    end
end
toc
fprintf('Coordinates = %.2d\n', double(swarm(1,4,:)));
fprintf('Function gCost = %.2d\n', func(swarm(1,4,:)));
fprintf('Maximum displacement = %.2d\n', max(max(abs(diff(swarm(:,1,:))))));
fprintf('Number of iterations = %.2d\n', k);

%% Another Adaptive technique that could be implemented, see parameter selection document
%r - particle relative distance from gbest
if func(swarm(i,1,:)) ~= 0
    r(i) = (func(swarm(i,1,:))-func(swarm(i,4,:)))/(func(swarm(i,1,:)));
elseif func(swarm(i,1,:)) == 0
    r(i) = 0;
end

%Inertia adaption
F = 2*(1-cos(pi/2)*r(i));
w(i) = w1*F+ w2; %--->w1 and w2 are some positive constants

%Social accelartion coefficient adaption (C2)
C(i) = C1*F+C2;

%C1 remains constant (cognitive acceelration coeffiecient)

%Adaptive parameters
r = zeros(S,1);
w = zeros(S,1);
C = zeros(S,1);
w1 = 0.3;
w2 = 0.2;
w3 = 1;

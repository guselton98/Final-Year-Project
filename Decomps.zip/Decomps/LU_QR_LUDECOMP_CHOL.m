clc; clear;
load('matlab1.mat')

%Find computaiton times of finindg matrices
n = 5;
time1 = zeros(n,4);

for i = 1:n
    tic;
    [L, U] = lu(SigY);
    time1(i,1) = toc;
end
for i = 1:n

    tic 
    [Lc, Uc] = LUdecomp(SigY);
    time1(i,2) =toc;
end
for i = 1:n

    tic 
    [Q, R] = qr(SigY);
    time1(i,3) =toc;
end
for i = 1:n
    
    tic 
    Rchol = chol(SigY);
    time1(i,4) =toc;
end

disp(['LU matrix: ', num2str(mean(time1(:,1)))])
disp(['L1U1 matrix: ', num2str(mean(time1(:,2)))])
disp(['QR matrix: ', num2str(mean(time1(:,3)))])
disp(['CHOL matrix: ', num2str(mean(time1(:,4)))])

%Find computation times of computing J
% J = Y^tSig^-1Y + log(det(sigy))
load('y.mat');
tic;
J = Y'*SigY^-1*Y;
toc;
n = 5;
time2 = zeros(n,4);
J = zeros(n,4);

for i = 1:n
    
    %LU
    tic;
    J(i,1) = Y'/U/L*Y;
    time2(i,1) = toc;
    
end

for i = 1:n
    %LUdecomp
    tic;
    J(i,2) = Y'/Uc/Lc*Y;
    time2(i,2) = toc;
end

for i = 1:n
    %QR
    tic;
    J(i,3) = Y'/R*Q'*Y;
    time2(i,3) = toc;
end

for i = 1:n
    %Chol
    tic;
    J(i,4) = Y'/Rchol/Rchol'*Y;
    time2(i,4) = toc;
end

disp(['LU cost: ', num2str(mean(time2(:,1)))])
disp(['L1U1 cost: ', num2str(mean(time2(:,2)))])
disp(['QR cost: ', num2str(mean(time2(:,3)))])
disp(['CHOL cost: ', num2str(mean(time2(:,4)))])

disp('Total Time: ')
disp(['LU total: ', num2str(mean(time1(:,1))+mean(time2(:,1)))])
disp(['L1U1 total: ', num2str(mean(time1(:,2))+mean(time2(:,2)))])
disp(['QR total: ', num2str(mean(time1(:,3))+mean(time2(:,3)))])
disp(['CHOL total: ', num2str(mean(time1(:,4))+mean(time2(:,4)))])-+